/* =========================================================
   Yuvakurazh 360° — left navigation (js/nav.js)
   Every page gets the same nav: the Yuvakurazh 360 brand
   (goes Home), Search and Post.
   Desktop: fixed sidebar.  Mobile (<=900px): slide-in drawer.
   ========================================================= */

(function (window, document) {
    "use strict";

    if (window.__ykSideNav) return;
    window.__ykSideNav = true;

    var AUTH_PAGES = ["login.html", "register.html"];

    function apiBase() {
        if (window.YK && window.YK.base) return window.YK.base;
        try { return localStorage.getItem("ykApiBase") || "/api"; } catch (e) { return "/api"; }
    }

    function getToken() {
        try { return localStorage.getItem("yuvaToken") || ""; } catch (e) { return ""; }
    }

    function currentPage() {
        var path = window.location.pathname.split("/").pop();
        return path || "index.html";
    }

    /* ------------------------------------------------------------------
       toast
    ------------------------------------------------------------------ */

    function toast(message, type) {
        var el = document.getElementById("ykNavToast");
        if (!el) {
            el = document.createElement("div");
            el.id = "ykNavToast";
            el.className = "yk-nav-toast";
            document.body.appendChild(el);
        }
        el.className = "yk-nav-toast show " + (type === "err" ? "err" : "ok");
        el.textContent = message;
        clearTimeout(el._timer);
        el._timer = setTimeout(function () {
            el.className = "yk-nav-toast " + (type === "err" ? "err" : "ok");
        }, 3400);
    }

    /* ------------------------------------------------------------------
       modal shell
    ------------------------------------------------------------------ */

    function closeModal(modal) {
        if (!modal) return;
        modal.classList.remove("open");
        setTimeout(function () {
            if (modal.parentNode) modal.parentNode.removeChild(modal);
        }, 200);
        document.body.style.overflow = "";
    }

    function openModal(html, onMount) {
        var modal = document.createElement("div");
        modal.className = "yk-modal";
        modal.innerHTML = html;
        document.body.appendChild(modal);
        document.body.style.overflow = "hidden";
        requestAnimationFrame(function () { modal.classList.add("open"); });

        modal.addEventListener("click", function (event) {
            if (event.target === modal || event.target.closest("[data-close]")) {
                closeModal(modal);
            }
        });
        if (onMount) onMount(modal);
        return modal;
    }

    /* ------------------------------------------------------------------
       Search — filters the live service list in place
    ------------------------------------------------------------------ */

    var serviceCache = null;

    function loadServices() {
        if (serviceCache) return Promise.resolve(serviceCache);
        return fetch(apiBase() + "/services")
            .then(function (res) { return res.json(); })
            .then(function (data) {
                serviceCache = data.services || [];
                return serviceCache;
            });
    }

    function searchMarkup() {
        return ''
            + '<div class="yk-modal-card yk-search-card">'
            +   '<div class="yk-modal-head">'
            +     '<h3><i class="fa-solid fa-magnifying-glass"></i> Search Services</h3>'
            +     '<button type="button" class="yk-modal-x" data-close aria-label="Close">'
            +       '<i class="fa-solid fa-xmark"></i>'
            +     '</button>'
            +   '</div>'
            +   '<div class="yk-search-box">'
            +     '<i class="fa-solid fa-magnifying-glass"></i>'
            +     '<input id="ykSearchInput" type="search" autocomplete="off"'
            +            ' placeholder="Search scholarship, certificate, job...">'
            +   '</div>'
            +   '<div id="ykSearchResults" class="yk-search-results">'
            +     '<p class="yk-search-hint">Loading services...</p>'
            +   '</div>'
            + '</div>';
    }

    function openSearch() {
        var modal = openModal(searchMarkup(), function (root) {
            var input = root.querySelector("#ykSearchInput");
            var out = root.querySelector("#ykSearchResults");
            input.focus();

            loadServices().then(function (services) {
                function render() {
                    var q = input.value.trim().toLowerCase();
                    if (!q) {
                        out.innerHTML = '<p class="yk-search-hint">Type to search ' + services.length
                            + ' government services.</p>';
                        return;
                    }
                    var hits = services.filter(function (s) {
                        var hay = [s.name, s.category, s.department, s.description]
                            .concat(s.keywords || []).join(" ").toLowerCase();
                        return q.split(/\s+/).every(function (word) {
                            return hay.indexOf(word) !== -1;
                        });
                    });

                    if (!hits.length) {
                        out.innerHTML = '<p class="yk-search-hint">No service matches &quot;'
                            + escapeHtml(input.value.trim()) + '&quot;.</p>';
                        return;
                    }

                    out.innerHTML = hits.map(function (s) {
                        var href = (s.page || "services.html") + "?service=" + encodeURIComponent(s.id);
                        return '<a class="yk-search-hit" href="' + href + '">'
                            + '<i class="fa-solid ' + (s.icon || "fa-circle") + '"></i>'
                            + '<span><strong>' + escapeHtml(s.name) + '</strong>'
                            + '<small>' + escapeHtml(s.category || "") + ' &middot; '
                            + escapeHtml(s.department || "") + '</small></span>'
                            + '<i class="fa-solid fa-chevron-right"></i>'
                            + '</a>';
                    }).join("");
                }

                input.addEventListener("input", render);
                render();
            }).catch(function () {
                out.innerHTML = '<p class="yk-search-hint">Could not reach the service list. '
                    + 'Is the backend running on port 5000?</p>';
            });
        });
        return modal;
    }

    /* ------------------------------------------------------------------
       Post — files a complaint to the backend
    ------------------------------------------------------------------ */

    var POST_CATEGORIES = [
        "General", "Scholarship", "Employment", "Welfare",
        "Women & Child", "Police", "Feedback"
    ];

    function postMarkup() {
        var signedIn = !!getToken();

        var options = POST_CATEGORIES.map(function (c) {
            return '<option>' + escapeHtml(c) + '</option>';
        }).join('');

        return ''
            + '<div class="yk-modal-card">'
            +   '<div class="yk-modal-head">'
            +     '<h3><i class="fa-solid fa-pen-to-square"></i> New Post</h3>'
            +     '<button type="button" class="yk-modal-x" data-close aria-label="Close">'
            +       '<i class="fa-solid fa-xmark"></i>'
            +     '</button>'
            +   '</div>'
            +   (signedIn ? '' : '<p class="yk-post-note">You need to sign in before posting.</p>')
            +   '<label class="yk-field">Title'
            +     '<input id="ykPostTitle" type="text" maxlength="120" required'
            +            ' placeholder="Write a title for your post"'
            +            (signedIn ? '' : ' disabled') + '>'
            +   '</label>'
            +   '<label class="yk-field">Category'
            +     '<select id="ykPostCategory"'
            +            (signedIn ? '' : ' disabled') + '>'
            +       options
            +     '</select>'
            +   '</label>'
+           '<label class="yk-field">Message'
            +     '<textarea id="ykPostMessage" rows="5" maxlength="1000"'
            +            ' placeholder="Share an update, a tip or a question"'
            +            (signedIn ? '' : ' disabled') + '></textarea>'
            +   '</label>'
            /* photo + secure toggle sit on one row */
            +   '<div class="yk-post-row">'
            +     '<button type="button" class="yk-post-photo" id="ykPostPhotoPick"'
            +            (signedIn ? '' : ' disabled') + '>'
            +       '<i class="fa-solid fa-camera"></i>'
            +       '<span id="ykPostPhotoName">Add photo</span>'
            +       '<input type="file" id="ykPostPhoto" accept="image/png,'
            +              'image/jpeg,image/webp,image/gif" hidden>'
            +     '</button>'
            +     '<label class="yk-switch" for="ykPostSecure">'
            +       '<input type="checkbox" id="ykPostSecure"'
            +              (signedIn ? '' : ' disabled') + '>'
            +       '<span class="yk-switch-track"><span class="yk-switch-dot"></span></span>'
            +       '<span class="yk-switch-text">'
            +         '<strong>Secure post</strong>'
            +         '<small>Only you can see this</small>'
            +       '</span>'
            +     '</label>'
            +   '</div>'
            +   '<div class="yk-post-preview" id="ykPostPreview" hidden>'
            +     '<img id="ykPostPreviewImg" alt="Selected photo">'
            +     '<button type="button" id="ykPostPhotoClear">'
            +       '<i class="fa-solid fa-xmark"></i>'
            +     '</button>'
            +   '</div>'
            +   '<div class="yk-modal-actions">'
            +     '<button type="button" class="yk-btn ghost" data-close>Cancel</button>'
            +     (signedIn
                   ? '<button type="button" class="yk-btn" id="ykPostSend">'
                     + '<i class="fa-solid fa-paper-plane"></i> Post</button>'
                   : '<a class="yk-btn" href="login.html">'
                     + '<i class="fa-solid fa-right-to-bracket"></i> Sign in</a>')
            +   '</div>'
            + '</div>';
    }

    function openPost() {
        return openModal(postMarkup(), function (root) {
            var send = root.querySelector("#ykPostSend");
            if (!send) return;

            var message = root.querySelector("#ykPostMessage");
            if (message) message.focus();

            /* ---------- photo ---------- */

            var pick = root.querySelector("#ykPostPhotoPick");
            var file = root.querySelector("#ykPostPhoto");
            var name = root.querySelector("#ykPostPhotoName");
            var preview = root.querySelector("#ykPostPreview");
            var previewImg = root.querySelector("#ykPostPreviewImg");
            var clear = root.querySelector("#ykPostPhotoClear");

            var chosen = null;

            function resetPhoto() {
                chosen = null;
                if (file) file.value = "";
                if (preview) preview.hidden = true;
                if (previewImg) previewImg.removeAttribute("src");
                if (name) name.textContent = "Add photo";
            }

            if (pick) {
                pick.addEventListener("click", function () {
                    file.click();
                });
            }

            if (file) {
                file.addEventListener("change", function () {
                    var photo = file.files && file.files[0];
                    if (!photo) { resetPhoto(); return; }

                    if (photo.size > 3 * 1024 * 1024) {
                        toast("A photo can be at most 3 MB", "err");
                        resetPhoto();
                        return;
                    }

                    if (photo.type && photo.type.indexOf("image/") !== 0) {
                        toast("Only image files are allowed", "err");
                        resetPhoto();
                        return;
                    }

                    var reader = new FileReader();
                    reader.onload = function () {
                        chosen = reader.result;
                        if (previewImg) previewImg.src = reader.result;
                        if (preview) preview.hidden = false;
                        if (name) name.textContent = "Photo added";
                    };
                    reader.onerror = function () {
                        toast("That photo could not be read", "err");
                        resetPhoto();
                    };
                    reader.readAsDataURL(photo);
                });
            }

            if (clear) {
                clear.addEventListener("click", resetPhoto);
            }

            /* ---------- send ---------- */

            send.addEventListener("click", function () {
                var title = root.querySelector("#ykPostTitle").value.trim();
                var body = root.querySelector("#ykPostMessage").value.trim();
                var category = root.querySelector("#ykPostCategory").value;
                var secure = root.querySelector("#ykPostSecure").checked;

                if (!title) {
                    toast("Add a title to your post", "err");
                    root.querySelector("#ykPostTitle").focus();
                    return;
                }

                if (!body && !chosen) {
                    toast("Write something or add a photo first", "err");
                    return;
                }

                var payload = {
                    title: title,
                    body: body,
                    category: category,
                    visibility: secure ? "private" : "public"
                };
                if (chosen) payload.photo = chosen;

                send.disabled = true;
                send.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Posting...';

                fetch(apiBase() + "/posts", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + getToken()
                    },
                    body: JSON.stringify(payload)
                })
                    .then(function (res) {
                        return res.json().then(function (data) {
                            return { ok: res.ok, data: data };
                        });
                    })
                    .then(function (out) {
                        if (!out.ok) {
                            throw new Error(out.data.error || "Could not post");
                        }
                        var flag = secure ? "Posted privately" : "Posted";
                        closeModal(root);
                        toast(flag);
                        /* the dashboard feed listens for this */
                        window.dispatchEvent(new CustomEvent("yk:post-created"));
                        if (typeof window.refreshPostBadge === "function") {
                            window.refreshPostBadge();
                        }
                    })
                    .catch(function (err) {
                        send.disabled = false;
                        send.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Post';
                        toast(err.message || "Could not post", "err");
                    });
            });
        });
    }

    function openChat() {
        var fab = document.getElementById("ykChatFab");
        if (fab) {
            fab.click();
            return;
        }
        window.location.href = "ai.html";
    }

    function escapeHtml(value) {
        return String(value == null ? "" : value).replace(/[&<>"']/g, function (c) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
        });
    }

    /* ------------------------------------------------------------------
       sidebar
    ------------------------------------------------------------------ */

    function buildSidebar() {
        var page = currentPage();

        var aside = document.createElement("aside");
        aside.className = "yk-side";
        aside.id = "ykSide";

        /* brand = Home */
        var brand = document.createElement("a");
        brand.className = "yk-side-brand";
        brand.href = "index.html";
        brand.innerHTML =
            '<img src="logo.png" alt="Yuvakurazh 360">'
            + '<span><strong>Yuvakurazh 360&deg;</strong>'
            + '<small>Government Services</small></span>';
        aside.appendChild(brand);

        var scroll = document.createElement("div");
        scroll.className = "yk-side-scroll";

        [
            ["index.html", "Home", "fa-house"],
            ["services.html", "Services", "fa-layer-group"],
            ["profile.html", "Profile", "fa-id-card"],
            ["settings.html", "Settings", "fa-gear"]
        ].forEach(function (item) {
            var link = document.createElement("a");
            link.className = "yk-side-link" + (item[0] === page ? " active" : "");
            link.href = item[0];
            link.innerHTML = '<i class="fa-solid ' + item[2] + '"></i><span>' + item[1] + "</span>";
            scroll.appendChild(link);
        });

        aside.appendChild(scroll);

        var foot = document.createElement("div");
        foot.className = "yk-side-foot";

        /* notifications and the dark / light toggle now live in
           Settings and the top bar, so they stay out of the sidebar */

        /* logout */
        if (AUTH_PAGES.indexOf(page) === -1) {
            var signout = document.createElement("button");
            signout.type = "button";
            signout.innerHTML =
                '<i class="fa-solid fa-arrow-right-from-bracket"></i><span>Logout</span>';
            signout.addEventListener("click", function () {
                if (typeof window.logout === "function") {
                    window.logout();
                    return;
                }
                try { sessionStorage.removeItem("yuvaSession"); } catch (e) {}
                window.location.href = "login.html";
            });
            foot.appendChild(signout);
        }

        aside.appendChild(foot);
        return aside;
    }

    /* ------------------------------------------------------------------
       boot
    ------------------------------------------------------------------ */

    function init() {
        var page = currentPage();

        /* drop any leftover instagram-theme flag */
        try {
            if (localStorage.getItem("yuvakurazhIg")) {
                document.body.classList.remove("ig");
                localStorage.setItem("yuvakurazhIg", "default");
            }
        } catch (e) {}

        /* login / register stay full screen */
        if (AUTH_PAGES.indexOf(page) !== -1) return;

        var overlay = document.createElement("div");
        overlay.className = "yk-side-overlay";
        overlay.id = "ykSideOverlay";
        document.body.appendChild(overlay);

        var button = document.createElement("button");
        button.type = "button";
        button.className = "yk-side-btn";
        button.id = "ykSideBtn";
        button.setAttribute("aria-label", "Open menu");
        button.innerHTML = '<i class="fa-solid fa-bars"></i>';
        document.body.appendChild(button);

        var sidebar = buildSidebar();
        document.body.insertBefore(sidebar, document.body.firstChild);
        document.body.classList.add("yk-has-side");

        function open() {
            sidebar.classList.add("open");
            overlay.classList.add("open");
            document.body.style.overflow = "hidden";
        }

        function close() {
            sidebar.classList.remove("open");
            overlay.classList.remove("open");
            document.body.style.overflow = "";
        }

        button.addEventListener("click", function () {
            if (sidebar.classList.contains("open")) { close(); } else { open(); }
        });

        overlay.addEventListener("click", close);

        document.addEventListener("keydown", function (event) {
            if (event.key === "Escape") close();
        });

        window.addEventListener("resize", function () {
            if (window.innerWidth > 900) {
                sidebar.classList.remove("open");
                overlay.classList.remove("open");
                document.body.style.overflow = "";
            }
        });

        /* legacy bottom tabs only — a page's own <nav> is left alone */
        document.querySelectorAll(".nav-links, .mobile-nav")
            .forEach(function (node) { node.style.display = "none"; });

        /* page scripts can open the composer too */
        window.ykOpenPost = openPost;
        window.ykOpenSearch = openSearch;

        /* website usage ping for the administrator console */
        if (!document.getElementById("ykTrackScript")) {
            var tag = document.createElement("script");

            tag.id = "ykTrackScript";
            tag.src = "js/track.js";
            tag.defer = true;
            document.head.appendChild(tag);
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }

})(window, document);
