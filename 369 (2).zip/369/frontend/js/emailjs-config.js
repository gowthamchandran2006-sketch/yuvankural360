/* =========================================================
   EMAILJS SETTINGS  -  edit these three values only
   ------------------------------------------------------------
   1. Create a free account at https://www.emailjs.com
   2. Connect an email service (Gmail / Outlook)
   3. Create an email template and copy the three IDs here
   ========================================================= */

window.YK_EMAIL_CONFIG = {

    publicKey: "oYcXim9o1846SxlFL",

    serviceId: "service_c9tcrut",

    templateId: "template_c133wka"

};
