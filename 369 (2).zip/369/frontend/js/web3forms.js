/* =========================================================
   WEB3FORMS  -  email copy of every submitted form
   ------------------------------------------------------------
   The portal already saves each submission locally and mails
   it through js/email-auth.js + js/emailjs.js. This helper
   sends the very same payload a second time through
   Web3Forms, so a plain inbox receives every submission even
   when EmailJS is not configured.

   Pages do not have to change: js/email-auth.js calls

        YK_WEB3FORMS.deliver(payload);

   for every payload it builds. A page that never uses the
   shared helper can call it directly:

        YK_WEB3FORMS.submit("loginForm");

   Opt a form out with:  <form data-yk-web3="off">

   Nothing here blocks or breaks a form: the send is
   fire-and-forget and every failure is swallowed.
   ========================================================= */

window.YK_WEB3FORMS = (function () {

    /* ---------- settings ---------- */

    const CONFIG = {
        endpoint: "https://api.web3forms.com/submit",
        access_key: "8620f2f4-fe6f-49f2-977e-2975cd04e7ad",
        from_name: "Yuvakurazh 360",
        subject_prefix: "New form submission - "
    };

    /* internal keys that only matter inside the portal */

    const INTERNAL = [
        "form_id",
        "page",
        "botcheck",
        "honeybot"
    ];

    /* never let these reach an inbox */

    const SECRET = /(pass|secret|token|otp|cvv|card|pin)/i;

    const SKIP_TYPES = [
        "file",
        "submit",
        "button",
        "image",
        "reset",
        "password",
        "hidden"
    ];

    const MAX_FIELDS = 24;
    const MAX_VALUE = 600;

    /* ---------- field helpers ---------- */

    function clean(value) {

        const text = String(
            value === undefined || value === null
                ? ""
                : value
        ).replace(/\s+/g, " ").trim();

        return text.length > MAX_VALUE
            ? text.slice(0, MAX_VALUE) + "..."
            : text;

    }

    function label(key) {

        return String(key || "value")
            .replace(/[_-]+/g, " ")
            .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
            .trim()
            .replace(/^./, c => c.toUpperCase());

    }

    function toKey(source) {

        return String(source || "")
            .replace(/[^\w]+/g, "_")
            .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
            .toLowerCase()
            .replace(/^_+|_+$/g, "");

    }

    function isSecret(key, type) {

        if (SKIP_TYPES.indexOf(String(type || "").toLowerCase()) !== -1)
            return true;

        return SECRET.test(String(key || ""));

    }

    /* ---------- payload collection ----------
       Only used when js/email-auth.js is not on the page. */

    function collect(form) {

        const payload = {};
        const fields = form.elements || [];
        let taken = 0;

        for (let i = 0; i < fields.length; i++) {

            const field = fields[i];

            if (!field || taken >= MAX_FIELDS) continue;

            const type = String(field.type || "").toLowerCase();

            if (type === "checkbox" || type === "radio") {

                if (!field.checked) continue;

            }

            const key = toKey(field.name || field.id);

            if (!key || isSecret(key, type)) continue;

            const value = clean(field.value);

            if (!value) continue;

            payload[key] = value;
            taken++;

        }

        return payload;

    }

    /* ---------- message text ---------- */

    function pageName() {

        const title = String(document.title || "");

        return clean(
            title.split("|")[0]
        ) || clean(location.pathname);

    }

    function findEmail(payload) {

        const keys = [
            "email",
            "email_id",
            "email_address",
            "emailid",
            "mail"
        ];

        const isEmail = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

        for (let i = 0; i < keys.length; i++) {

            const value = String(payload[keys[i]] || "").trim();

            if (isEmail.test(value))
                return value;

        }

        /* forms without a dedicated email field, the sign-in
           page for example, still carry one usable address */

        const values = Object.keys(payload);

        for (let i = 0; i < values.length; i++) {

            const value = String(payload[values[i]] || "").trim();

            if (isEmail.test(value))
                return value;

        }

        return "";

    }

    function messageText(payload, page, formLabel) {

        const lines = [
            "Page: " + page,
            "Form: " + (formLabel || "form"),
            "Sent: " + new Date().toLocaleString(),
            ""
        ];

        const keys = Object.keys(payload);

        keys.forEach(function (key) {

            if (INTERNAL.indexOf(key) !== -1) return;

            const value = clean(payload[key]);

            if (!value) return;

            lines.push(label(key) + ": " + value);

        });

        if (lines.length === 4)
            lines.push("(no readable fields in this form)");

        return lines.join("\n");

    }

    /* ---------- the send ---------- */

    function resolveForm(formOrId) {

        if (typeof formOrId === "string")
            return document.getElementById(formOrId);

        return formOrId || null;

    }

    function deliver(payload, form) {

        const data = payload || {};

        if (
            form
            && form.getAttribute
            && form.getAttribute("data-yk-web3") === "off"
        ) {

            return Promise.resolve({
                sent: false,
                reason: "opted-out"
            });

        }

        if (typeof FormData === "undefined")
            return Promise.resolve({
                sent: false,
                reason: "formdata-missing"
            });

        const formLabel =
            data.form_id
            || (form && form.id)
            || "form";

        const page = pageName();

        const service =
            clean(data.service)
            || "";

        const body = new FormData();

        body.append("access_key", CONFIG.access_key);
        body.append("from_name", CONFIG.from_name);
        body.append(
            "subject",
            CONFIG.subject_prefix
            + page
            + (service ? " - " + service : "")
        );

        body.append(
            "message",
            messageText(data, page, formLabel)
        );

        if (data.name)
            body.append("name", clean(data.name));

        const email = findEmail(data);

        if (email)
            body.append("replyto", email);

        body.append("botcheck", "");
        body.append("honeybot", "");

        window.YK_WEB3FORMS_LAST = {
            page: page,
            form: formLabel,
            subject: CONFIG.subject_prefix + page,
            email: email
        };

        try {

            return fetch(CONFIG.endpoint, {
                method: "POST",
                body: body,
                mode: "cors",
                keepalive: true
            })
                .then(function (response) {

                    return response.json()
                        .catch(function () {
                            return {};
                        });

                })
                .then(function (result) {

                    if (result && result.success === false) {

                        console.warn(
                            "Yuvakurazh 360: web3forms rejected the submission",
                            result.message
                        );

                    }

                    return {
                        sent: !!(result && result.success),
                        reason: result && result.message
                            ? result.message
                            : "sent"
                    };

                })
                .catch(function (error) {

                    console.warn(
                        "Yuvakurazh 360: web3forms send failed",
                        error
                    );

                    return {
                        sent: false,
                        reason: "network"
                    };

                });

        } catch (error) {

            console.warn(
                "Yuvakurazh 360: web3forms could not send",
                error
            );

            return Promise.resolve({
                sent: false,
                reason: "blocked"
            });

        }

    }

    /* ---------- public api ---------- */

    return {

        settings: CONFIG,

        /* Send a payload that was already built by
           js/email-auth.js. */

        deliver: function (payload, form) {

            return deliver(payload, form);

        },

        /* Build the payload from the form (reusing
           js/email-auth.js when the page has it) and send it. */

        submit: function (formOrId, extra) {

            const form = resolveForm(formOrId);

            if (!form) {

                console.warn(
                    "Yuvakurazh 360: web3forms could not find the form",
                    formOrId
                );

                return Promise.resolve({
                    sent: false,
                    reason: "form-not-found"
                });

            }

            if (form.getAttribute("data-yk-web3") === "off")
                return Promise.resolve({
                    sent: false,
                    reason: "opted-out"
                });

            let payload;

            try {

                payload = window.YK_EMAIL_AUTH
                    ? window.YK_EMAIL_AUTH.payload(form, extra)
                    : collect(form);

            } catch (error) {

                console.warn(
                    "Yuvakurazh 360: web3forms payload failed",
                    error
                );

                return Promise.resolve({
                    sent: false,
                    reason: "payload-failed"
                });

            }

            if (extra) {

                Object.keys(extra).forEach(function (key) {

                    const value = clean(extra[key]);

                    if (value) payload[key] = value;

                });

            }

            return deliver(payload, form);

        }

    };

})();