/* =========================================================
   EMAILJS HELPER  -  shared by every form on the portal
   ------------------------------------------------------------
   Usage inside a submit handler:

       YK_EMAIL.send("issueForm", {
           name: "...",
           email: "..."
       });

   The helper never throws. If EmailJS is not configured or
   the CDN is blocked, the portal still saves the record in
   localStorage exactly as before.

   Only the keys listed in "data" are emailed - the form is
   never serialised, so passwords and unnamed inputs can
   never be included by accident.
   ========================================================= */

window.YK_EMAIL = (function () {

    const SDK =
        "https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js";

    let loading = null;

    function config() {

        return window.YK_EMAIL_CONFIG || {};

    }

    function missing(value) {

        return (
            !value ||
            String(value).indexOf("YOUR_") === 0
        );

    }

    /* the SDK is loaded on demand so a blocked CDN cannot
       slow down the page */

    function loadSdk() {

        if (window.emailjs) {

            return Promise.resolve(window.emailjs);

        }

        if (loading) return loading;

        loading = new Promise(function (resolve, reject) {

            const script =
                document.createElement("script");

            script.src = SDK;
            script.async = true;

            script.onload = function () {

                if (window.emailjs) {

                    resolve(window.emailjs);

                } else {

                    reject(
                        new Error("EmailJS SDK loaded but missing")
                    );

                }

            };

            script.onerror = function () {

                reject(
                    new Error("EmailJS SDK could not load")
                );

            };

            document.head.appendChild(script);

        });

        return loading;

    }

    function isConfigured() {

        const c = config();

        return (
            !missing(c.publicKey) &&
            !missing(c.serviceId) &&
            !missing(c.templateId)
        );

    }

    /* Never allow a credential to leave the browser, even if a
       page accidentally passes one. Only the exact keys below are
       dropped, so safe fields such as "pincode" still go through. */

    const BLOCKED = [
        "password",
        "password2",
        "pass",
        "pwd",
        "otp",
        "cvv",
        "card_number",
        "cardnumber",
        "security_answer"
    ];

    function formEmail(form) {

        const input =
            form.querySelector(
                'input[type="email"]'
            ) ||
            form.querySelector(
                'input[name="email"]'
            );

        return input ? input.value : "";

    }

    function initials(name) {

        return String(name || "User")
            .trim()
            .split(/\s+/)
            .slice(0, 2)
            .map(function (part) {

                return part.charAt(0).toUpperCase();

            })
            .join("");

    }

    return {

        isConfigured: isConfigured,

        /* Send the values of a form element through EmailJS.
           data: plain object of extra / already collected
           values. Resolves { sent:Boolean, reason:String } */

        send: function (formId, data) {

            const form =
                document.getElementById(formId);

            if (!form) {

                return Promise.resolve({
                    sent: false,
                    reason: "form-not-found"
                });

            }

            if (!isConfigured()) {

                console.info(
                    "Yuvakurazh 360: EmailJS is not configured yet - the record was saved locally only."
                );

                return Promise.resolve({
                    sent: false,
                    reason: "not-configured"
                });

            }

            const payload = data || {};

            return loadSdk().then(function (sdk) {

                sdk.init({
                    publicKey: config().publicKey
                });

                /* template params used by the EmailJS template */

                const params = {

                    form_id: formId,

                    to_name: "Yuvakurazh 360°",

                    reply_to:
                        payload.email ||
                        formEmail(form) ||
                        "no-reply@yuvakurazh.app",

                    /* EmailJS gets exactly these values - nothing
                       is read from the form itself, so hidden or
                       unnamed inputs can never be included */

                    submitted_at:
                        new Date().toLocaleString("en-IN"),

                    page:
                        location.pathname.split("/").pop() ||
                        "index.html",

                    sender_initials: initials(
                        payload.name || formEmail(form)
                    )

                };

                Object.keys(payload).forEach(
                    function (key) {

                        const value = payload[key];

                        if (
                            value === undefined ||
                            value === null ||
                            value === "" ||
                            BLOCKED.indexOf(key) !== -1
                        ) {

                            return;

                        }

                        params[key] = value;

                    }
                );

                return sdk
                    .send(
                        config().serviceId,
                        config().templateId,
                        params
                    )

                    .then(function (response) {

                        console.log(
                            "Yuvakurazh 360: EmailJS sent",
                            response.status,
                            response.text
                        );

                        return {
                            sent: true,
                            reason: "ok"
                        };

                    })

                    .catch(function (error) {

                        console.error(
                            "Yuvakurazh 360: EmailJS error",
                            error
                        );

                        return {
                            sent: false,
                            reason: "send-failed"
                        };

                    });

            }).catch(function (error) {

                console.warn(
                    "Yuvakurazh 360: EmailJS unavailable -",
                    error.message
                );

                return {
                    sent: false,
                    reason: "sdk-unavailable"
                };

            });

        }

    };

})();
