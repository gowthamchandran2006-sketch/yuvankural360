/* Website usage ping.

   Sends one small request per page load so the administrator console can show
   how many people used the website. Nothing personal is included: no email,
   no IP address, no user agent. The id below is a random string kept in this
   browser only, so the same person is counted once per day. */

(function (){

    "use strict";

    /* the admin console and its sign-in page stay out of the numbers */
    if(/admin(-login)?\.html$/.test(location.pathname)){
        return;
    }

    if(window.YK_TRACK === false){
        return;
    }

    var KEY = "ykVisitorId";

    function visitorId(){
        try{
            var id = localStorage.getItem(KEY);

            if(!id){
                id = "v" + Date.now().toString(36)
                    + Math.random().toString(36).slice(2, 10);

                localStorage.setItem(KEY, id);
            }

            return id;
        }
        catch(e){
            return "v" + Math.random().toString(36).slice(2, 12);
        }
    }

    function send(){
        var page = location.pathname.split("/").pop() || "index.html";

        var body = JSON.stringify({
            page: page,
            visitor: visitorId()
        });

        var base = "";

        try{
            var saved = localStorage.getItem("ykApiBase");

            if(saved){
                base = String(saved).replace(/\/+$/, "");
            }
        }
        catch(e){}

        if(!base){
            if(location.protocol === "file:"){
                return;
            }

            base = location.origin;
        }

        /* quiet on purpose: a failed ping must never disturb the page */
        try{
            if(navigator.sendBeacon){
                navigator.sendBeacon(
                    base + "/api/track/visit",
                    new Blob([body], { type: "application/json" })
                );

                return;
            }

            fetch(base + "/api/track/visit", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: body,
                keepalive: true
            }).catch(function (){});

        }
        catch(e){}
    }

    if(document.readyState === "loading"){
        document.addEventListener(
            "DOMContentLoaded",
            send,
            { once: true }
        );
    }
    else{
        send();
    }

    window.YK_TRACK_VISIT = send;

})();