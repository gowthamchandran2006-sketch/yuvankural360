/* =========================================================
   FIREBASE ANALYTICS
   Loaded on every Yuvakurazh 360 page as a module so page
   views are measured across the whole portal.

   Note: the config below is the public Firebase web config.
   It is safe to ship in the browser - never put service
   account keys or admin credentials in a file like this.
   ========================================================= */

import { initializeApp, getApps, getApp } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-analytics.js";

const firebaseConfig = {

    apiKey: "AIzaSyArovX-idqRgKuW7_xcMTCuookke5wbaAU",
    authDomain: "yuvakurazh-360.firebaseapp.com",
    projectId: "yuvakurazh-360",
    storageBucket: "yuvakurazh-360.firebasestorage.app",
    messagingSenderId: "851522735210",
    appId: "1:851522735210:web:ad4f1e41dfda2680c10e13",
    measurementId: "G-6N1YH382HC"

};

try{

    /* reuse the app if something already created it, otherwise
       Firebase throws "App named '[DEFAULT]' already exists" */

    const app =
        getApps().length
            ? getApp()
            : initializeApp(firebaseConfig);

    const analytics = getAnalytics(app);

    window.ykAnalytics = analytics;

    console.log(
        "Yuvakurazh 360: Firebase Analytics ready",
        firebaseConfig.projectId,
        firebaseConfig.measurementId
    );

}
catch(error){

    /* Analytics blocked (offline, ad-blocker or file://)
       must never stop the portal from working */

    window.ykAnalytics = null;

    console.warn(
        "Yuvakurazh 360: Firebase Analytics unavailable -",
        error && error.message
    );

}
