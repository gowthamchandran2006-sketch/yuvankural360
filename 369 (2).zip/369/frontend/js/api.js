/* =========================================================
   Yuvakurazh 360° — Frontend API client (js/api.js)
   Talks to the Python/Flask backend at /api, with safe
   offline fallback so the static demo still works without
   the server running.
========================================================= */

(function (window) {
    "use strict";

    var BASE = "/api";
    try {
        if (localStorage.getItem("ykApiBase")) {
            BASE = localStorage.getItem("ykApiBase");
        }
    } catch (e) {}

    var TOKEN_KEY = "yuvaToken";

    var YK = window.YK || {};
    YK.base = BASE;
    YK.config = { online: null, checked: false };

    function getToken() {
        try { return localStorage.getItem(TOKEN_KEY) || ""; } catch (e) { return ""; }
    }
    function setToken(t) {
        try { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); } catch (e) {}
    }
    YK.token = getToken;
    YK.setToken = setToken;

    function request(path, opts) {
        opts = opts || {};
        var headers = { "Content-Type": "application/json" };
        var token = opts.token !== undefined ? opts.token : (opts.auth ? getToken() : "");
        if (token) {
            headers["Authorization"] = "Bearer " + token;
        }
        var init = {
            method: opts.method || "GET",
            headers: headers,
            credentials: "same-origin"
        };
        if (opts.body !== undefined) {
            init.body = JSON.stringify(opts.body);
        }
        var ctrl;
        if (typeof AbortController !== "undefined") {
            ctrl = new AbortController();
            init.signal = ctrl.signal;
        }
        var timer = setTimeout(function () {
            if (ctrl && ctrl.abort) { try { ctrl.abort(); } catch (e) {} }
        }, 3500);

        return fetch(BASE + path, init).then(function (res) {
            return res.json().catch(function () { return {}; });
        }).then(function (data) {
            clearTimeout(timer);
            return data;
        }).catch(function (err) {
            clearTimeout(timer);
            YK.config.online = false;
            throw err;
        });
    }
    YK.request = request;

    function health() {
        return request("/health").then(function (res) {
            YK.config.online = !!(res && res.status === "ok");
            YK.config.checked = true;
            return YK.config.online;
        }).catch(function () {
            YK.config.online = false;
            YK.config.checked = true;
            return false;
        });
    }
    YK.health = health;

    /* ---------- routes ---------- */
    function login(user, password) {
        return request("/auth/login", { method: "POST", body: { user: user, password: password } });
    }
    function register(data) {
        return request("/auth/register", { method: "POST", body: data });
    }
    function me() {
        return request("/auth/me", { auth: true });
    }
    function logout() {
        return request("/auth/logout", { method: "POST", body: {}, auth: true });
    }
    function changePassword(currentPassword, newPassword, confirmPassword) {
        return request("/auth/change-password", {
            method: "POST",
            body: {
                currentPassword: currentPassword,
                newPassword: newPassword,
                confirmPassword: confirmPassword || ""
            },
            auth: true
        });
    }
    function services() {
        return request("/services");
    }
    function eligibility(profile) {
        return request("/services/eligibility-check", { method: "POST", body: profile });
    }
    function createApplication(data) {
        return request("/applications", { method: "POST", body: data, auth: true });
    }
    function myApplications() {
        return request("/applications", { auth: true });
    }
    function track(id) {
        return request("/applications/" + encodeURIComponent(id) + "/status", { auth: true });
    }
    function createComplaint(data) {
        return request("/complaints", { method: "POST", body: data, auth: true });
    }
    function myComplaints() {
        return request("/complaints", { auth: true });
    }
    function uploadDocument(data) {
        return request("/documents", { method: "POST", body: data, auth: true });
    }
    function myDocuments() {
        return request("/documents", { auth: true });
    }
    function createCase(data) {
        return request("/cases", { method: "POST", body: data, auth: true });
    }
    function myCases() {
        return request("/cases", { auth: true });
    }
    function myNotifications() {
        return request("/notifications", { auth: true });
    }
    function posts(limit) {
        return request("/posts?limit=" + (limit || 50), { auth: true });
    }
    function createPost(body, title, category) {
        return request("/posts", {
            method: "POST",
            auth: true,
            body: { body: body, title: title || "", category: category || "General" }
        });
    }
    function likePost(id) {
        return request("/posts/" + encodeURIComponent(id) + "/like", { method: "POST", auth: true, body: {} });
    }
    YK.posts = posts;
    YK.createPost = createPost;
    YK.likePost = likePost;
    function chat(message) {
        return request("/chat", { method: "POST", body: { message: message } });
    }
    function officerLogin(email, password) {
        return request("/officers/login", { method: "POST", body: { email: email, password: password } });
    }

    /* Administrator console. Its token is kept apart from the citizen
       one, so signing in here never disturbs a normal session. */
    function adminLogin(email, password) {
        return request("/admin/login", { method: "POST", body: { email: email, password: password } });
    }
    function adminOverview(token) {
        return request("/admin/overview", { token: token });
    }
    function adminLogout(token) {
        return request("/admin/logout", { method: "POST", body: {}, token: token });
    }
    function adminCases(token, opts) {
        var o = opts || {};
        var qs = [];

        if (o.status) qs.push("status=" + encodeURIComponent(o.status));
        if (o.q) qs.push("q=" + encodeURIComponent(o.q));
        qs.push("limit=" + encodeURIComponent(o.limit || 25));

        return request("/admin/cases?" + qs.join("&"), { token: token });
    }
    function adminPeople(token, opts) {
        var o = opts || {};
        var qs = ["limit=" + encodeURIComponent(o.limit || 25)];

        if (o.q) qs.push("q=" + encodeURIComponent(o.q));

        return request("/admin/people?" + qs.join("&"), { token: token });
    }
    function adminApplications(token, opts) {
        var o = opts || {};
        var qs = [];

        if (o.status) qs.push("status=" + encodeURIComponent(o.status));
        if (o.q) qs.push("q=" + encodeURIComponent(o.q));
        qs.push("limit=" + encodeURIComponent(o.limit || 25));

        return request("/admin/applications?" + qs.join("&"), { token: token });
    }
    function adminComplaints(token, opts) {
        var o = opts || {};
        var qs = [];

        if (o.status) qs.push("status=" + encodeURIComponent(o.status));
        if (o.q) qs.push("q=" + encodeURIComponent(o.q));
        qs.push("limit=" + encodeURIComponent(o.limit || 25));

        return request("/admin/complaints?" + qs.join("&"), { token: token });
    }

    /* ---------- Yuvakurazh SIH core ---------- */
    function registry() {
        return request("/registry");
    }
    function routing(message) {
        return request("/registry/routing?q=" + encodeURIComponent(message));
    }
    function routeQuery(message) {
        return request("/chat/route", { method: "POST", body: { message: message } });
    }
    function trackCase(caseId) {
        return request("/cases/track?caseId=" + encodeURIComponent(caseId), { auth: true });
    }
    function officerStats() {
        return request("/officers/stats", { auth: true });
    }
    function officerCases() {
        return request("/officers/cases", { auth: true });
    }
    function officerUpdate(data) {
        return request("/officers/case/update", { method: "POST", body: data, auth: true });
    }
    function officerCaseSummary(caseId) {
        return request("/officers/case-summary", { method: "POST", body: { caseId: caseId }, auth: true });
    }
    function auditLog(params) {
        var q = params ? "?" + new URLSearchParams(params).toString() : "";
        return request("/audit" + q, { auth: true });
    }
    function consents() {
        return request("/consents", { auth: true });
    }
    function grantConsent(data) {
        return request("/consents", { method: "POST", body: data, auth: true });
    }
    function consentReuse(dataKey) {
        return request("/consents/reuse", { method: "POST", body: { dataKey: dataKey || "profile" }, auth: true });
    }
    function unseenNotifications() {
        return request("/notifications/unseen", { auth: true });
    }

    YK.login = login;
    YK.register = register;
    YK.me = me;
    YK.logout = logout;
    YK.changePassword = changePassword;
    YK.services = services;
    YK.eligibility = eligibility;
    YK.createApplication = createApplication;
    YK.myApplications = myApplications;
    YK.track = track;
    YK.createComplaint = createComplaint;
    YK.myComplaints = myComplaints;
    YK.uploadDocument = uploadDocument;
    YK.myDocuments = myDocuments;
    YK.createCase = createCase;
    YK.myCases = myCases;
    YK.myNotifications = myNotifications;
    YK.chat = chat;
    YK.officerLogin = officerLogin;
    YK.adminLogin = adminLogin;
    YK.adminOverview = adminOverview;
    YK.adminLogout = adminLogout;
    YK.adminCases = adminCases;
    YK.adminPeople = adminPeople;
    YK.adminApplications = adminApplications;
    YK.adminComplaints = adminComplaints;
    YK.registry = registry;
    YK.routing = routing;
    YK.routeQuery = routeQuery;
    YK.trackCase = trackCase;
    YK.officerStats = officerStats;
    YK.officerCases = officerCases;
    YK.officerUpdate = officerUpdate;
    YK.officerCaseSummary = officerCaseSummary;
    YK.auditLog = auditLog;
    YK.consents = consents;
    YK.grantConsent = grantConsent;
    YK.consentReuse = consentReuse;
    YK.unseenNotifications = unseenNotifications;

    /* ---------- backend-first auth with demo fallback ---------- */
    YK.tryLogin = function (user, password) {
        return health().then(function (online) {
            if (!online) return null;
            return login(user, password).then(function (res) {
                if (res && res.token) {
                    setToken(res.token);
                    return res;
                }
                return null;
            }).catch(function () { return null; });
        });
    };

    YK.tryRegister = function (data) {
        return health().then(function (online) {
            if (!online) return null;
            return register(data).then(function (res) {
                if (res && (res.token || (res.user && res.user.id))) {
                    if (res.token) setToken(res.token);
                    return res;
                }
                return null;
            }).catch(function () { return null; });
        });
    };

    window.YK = YK;

    /* warm up connectivity check (non-blocking) */
    health();

})(window);