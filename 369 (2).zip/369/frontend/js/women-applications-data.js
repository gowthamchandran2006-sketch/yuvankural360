/* =========================================================
   WOMEN POLICE DEPARTMENT - SHARED APPLICATION DATA
   Used by women-child.html (the four boxes) and
   women-applications.html (the application detail views),
   so both pages always show the same numbers.

   Status updates are stored in "yuvaWomenApplications"
   as { "WAP-2026-0142": "resolved", ... }.

   Cases filed from women-child.html are kept in
   "yuvaWomenNewCases" and are appended to the same list, so
   a new case shows up in the summary counts and in
   women-applications.html as well.
   ========================================================= */

window.WOMEN_VIEWS = [
    {
        key: "total",
        label: "Total Applications",
        short: "Total",
        hint: "Every application received by the Women Police Department.",
        icon: "fa-solid fa-folder-open",
        color: "linear-gradient(135deg,#9d174d,#7c3aed)",
        status: null
    },
    {
        key: "pending",
        label: "Pending Applications",
        short: "Pending",
        hint: "Applications waiting for a first review by the department.",
        icon: "fa-solid fa-clock",
        color: "linear-gradient(135deg,#f59e0b,#f97316)",
        status: "pending"
    },
    {
        key: "progress",
        label: "In Process",
        short: "In Process",
        hint: "Applications a Women Police officer is actively handling.",
        icon: "fa-solid fa-spinner",
        color: "linear-gradient(135deg,#ec4899,#a855f7)",
        status: "progress"
    },
    {
        key: "resolved",
        label: "Resolved Applications",
        short: "Resolved",
        hint: "Applications completed and closed by the department.",
        icon: "fa-solid fa-circle-check",
        color: "linear-gradient(135deg,#10b981,#0d9488)",
        status: "resolved"
    }
];


window.WOMEN_STATUS_LABEL = {
    pending: "Pending",
    progress: "In Process",
    resolved: "Resolved",
    rejected: "Rejected"
};


/* response text shown as the current action taken */

window.WOMEN_DEFAULT_ACTION = {
    pending: "Queued for officer review",
    progress: "Under active processing",
    resolved: "Closed by the department",
    rejected: "Closed without action"
};


window.WOMEN_BASE_APPLICATIONS = [
    {
        id: "WAP-2026-0142",
        name: "Anitha Rao",
        location: "Warangal, Telangana",
        proof: "Aadhaar copy and call recording submitted",
        type: "Safety Assistance",
        status: "pending",
        priority: "high",
        date: "28 Sep 2026",
        description:
            "Citizen reported domestic harassment and repeated threatening phone calls from an unknown number.",
        action: "Assigned to Women Safety Desk - first response pending"
    },
    {
        id: "WAP-2026-0138",
        name: "Divya Prasad",
        location: "Hyderabad, Telangana",
        proof: "Birth certificate and custody application attached",
        type: "Child Protection",
        status: "progress",
        priority: "high",
        date: "27 Sep 2026",
        description:
            "Request for child custody guidance and protection support from the Child Welfare Desk.",
        action: "Child Welfare Officer visit scheduled this week"
    },
    {
        id: "WAP-2026-0131",
        name: "Sunitha Bai",
        location: "Nizamabad, Telangana",
        proof: "Ration card and property documents uploaded",
        type: "Legal Aid",
        status: "pending",
        priority: "medium",
        date: "27 Sep 2026",
        description:
            "Citizen requested free legal counselling for a property and maintenance dispute.",
        action: "Awaiting document verification"
    },
    {
        id: "WAP-2026-0127",
        name: "Meera Kumari",
        location: "Karimnagar, Telangana",
        proof: "Aadhaar copy and community certificate submitted",
        type: "Women Empowerment",
        status: "progress",
        priority: "medium",
        date: "26 Sep 2026",
        description:
            "Citizen applied for skill training and self-employment support under the empowerment scheme.",
        action: "Skill training enrolment confirmed"
    },
    {
        id: "WAP-2026-0119",
        name: "Lakshmi Devi",
        location: "Khammam, Telangana",
        proof: "Hospital bill and Aadhaar copy verified",
        type: "Welfare Support",
        status: "resolved",
        priority: "medium",
        date: "25 Sep 2026",
        description:
            "Citizen requested financial assistance for medical treatment of her family member.",
        action: "Resolved - assistance amount disbursed"
    },
    {
        id: "WAP-2026-0112",
        name: "Priya Sharma",
        location: "Vijayawada, Andhra Pradesh",
        proof: "Shift letter and address proof submitted",
        type: "Transit Assistance",
        status: "resolved",
        priority: "low",
        date: "24 Sep 2026",
        description:
            "Citizen requested safe late night travel support for her shift timings.",
        action: "Resolved - safe transit arranged with escort"
    },
    {
        id: "WAP-2026-0104",
        name: "Kavitha Reddy",
        location: "Warangal, Telangana",
        proof: "Screenshots and witness statement attached",
        type: "Safety Assistance",
        status: "progress",
        priority: "high",
        date: "23 Sep 2026",
        description:
            "Citizen reported stalking behaviour by a colleague and asked for police verification.",
        action: "Police verification of the accused in progress"
    },
    {
        id: "WAP-2026-0096",
        name: "Anjali Verma",
        location: "Siddipet, Telangana",
        proof: "School report card and fee receipt uploaded",
        type: "Child Education Support",
        status: "resolved",
        priority: "low",
        date: "22 Sep 2026",
        description:
            "Guardian requested continued study support and fee concession for her child.",
        action: "Resolved - scholarship support granted"
    }
];


window.readWomenStore = function (key) {

    try {
        return JSON.parse(
            localStorage.getItem(key)
        );
    } catch (e) {
        return null;
    }

};


/* every application the department knows about */

window.getWomenNewCases = function () {

    const list =
        window.readWomenStore("yuvaWomenNewCases") || [];

    return Array.isArray(list) ? list : [];

};


window.saveWomenNewCase = function (record) {

    const list = window.getWomenNewCases();

    list.push(record);

    try {
        localStorage.setItem(
            "yuvaWomenNewCases",
            JSON.stringify(list)
        );
    } catch (e) {}

    return record;

};


window.getWomenApplications = function () {

    const list =
        window.WOMEN_BASE_APPLICATIONS.map(function (item) {
            return Object.assign({}, item);
        });

    const overrides =
        window.readWomenStore("yuvaWomenApplications") || {};

    list.forEach(function (item) {

        if (overrides[item.id]) {

            item.status = overrides[item.id];

            item.action =
                window.WOMEN_DEFAULT_ACTION[item.status];

        }

    });


    /* cases filed by citizens from women-child.html */

    window.getWomenNewCases().forEach(function (item) {

        if (!item || !item.id) {
            return;
        }

        const status =
            overrides[item.id] || item.status || "pending";

        list.push(
            Object.assign({}, item, {
                status: status,
                action:
                    item.action
                    || window.WOMEN_DEFAULT_ACTION[status]
            })
        );

    });


    list.sort(function (a, b) {
        return b.id.localeCompare(a.id);
    });


    return list;

};


window.countWomenApplications = function (status) {

    const all = window.getWomenApplications();

    if (!status)
        return all.length;

    return all.filter(function (item) {
        return item.status === status;
    }).length;

};