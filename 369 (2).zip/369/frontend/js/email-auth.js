/* =========================================================
   EMAIL AUTH  -  one shared submit handler for every form
   ------------------------------------------------------------
   Pages no longer build their own EmailJS payload. On submit
   they just call:

        YK_EMAIL_AUTH.submit("educationForm");

   The helper reads the form that the visitor filled in, picks
   up the entered email address, name, mobile number and every
   useful field, works out which service the form belongs to,
   and hands the result to js/emailjs.js.

   Anything the helper cannot see in the DOM (an application id
   that only exists in JavaScript, for example) is passed in:

        YK_EMAIL_AUTH.submit("generalForm", {
            service: current.name,
            reference: id
        });

   Opt a form out with:  <form data-yk-email="off">
   ========================================================= */

window.YK_EMAIL_AUTH = (function () {

    /* ---------- field helpers ---------- */

    const SYNONYMS = {
        fullname: "name",
        applicantname: "name",
        studentname: "name",
        documentname: "name",
        username: "name",
        fullnameuser: "name",

        phone: "mobile",
        mobileno: "mobile",
        contactnumber: "mobile",

        emailid: "email",
        emailaddress: "email",

        dob: "date_of_birth",
        dateofbirth: "date_of_birth",

        marks: "percentage",
        mark: "percentage",

        taluka: "taluk",

        aadhaarnumber: "aadhaar",
        rationcardnumber: "ration_card",

        details: "description",
        issuedescription: "description",
        message: "description",

        issuecategory: "category",
        documentcategory: "category",

        qualification: "qualification",
        passingyear: "passing_year",
        studyyear: "year",
        classlevel: "class_level",
        educationlevel: "class_level",

        community: "community",
        religion: "religion",
        caste: "caste",
        nationality: "nationality",

        parentname: "parent_name",
        fathername: "father_name",
        mothername: "mother_name",
        relation: "relation",

        profession: "profession",
        skills: "skills",
        experience: "experience",
        interest: "interest",

        school: "school",
        schoolname: "school",
        collegename: "college",
        college: "college",

        district: "district",
        state: "state",
        pincode: "pincode",
        village: "village",
        address: "address",
        location: "location",
        doorno: "door_no",
        street: "street",

        reference: "reference",
        referenceid: "reference",
        referencekey: "reference"
    };

    /* internal fields that must never reach an email */

    const SKIP_KEYS = [
        "password",
        "password2",
        "pass",
        "pwd",
        "otp",
        "cvv",
        "card_number",
        "cardnumber",
        "security_answer",
        "photo",
        "photo_name",
        "photoname",
        "file",
        "filename",
        "file_name",
        "upload",
        "draft",
        "remember",
        "agree",
        "terms",
        "anonymous"
    ];

    const SKIP_TYPES = [
        "file",
        "submit",
        "button",
        "image",
        "reset",
        "password"
    ];

    /* prefixes used by the form field ids, dropped so
       ccName -> name and empMobile -> mobile */

    const PREFIXES = [
        "cc",
        "emp",
        "scholar",
        "education",
        "student",
        "reg",
        "yuvanumber",
        "yuva",
        "g",
        "f"
    ];

    const SERVICES = {
        applyForm: "AI Service Assistant",
        generalForm: "Certificate",
        ccForm: "Community Certificate",
        uploadForm: "Document Request",
        educationForm: "Education Service",
        empForm: "Employment",
        grievanceForm: "Grievance",
        issueForm: "Report Issue",
        scholarshipForm: "Scholarship",
        registerForm: "New Registration",
        loginForm: "Login"
    };

    const REFERENCE_IDS = [
        "applicationId",
        "applicationID",
        "application_id",
        "ccApplicationId",
        "empApplicationId",
        "scholarshipApplicationId",
        "documentId",
        "caseId",
        "refId",
        "refNumber",
        "trackingId"
    ];

    const MAX_VALUE = 600;
    const MAX_FIELDS = 24;

    function toKey(source) {

        const raw = String(source || "")
            .toLowerCase()
            .replace(/[^a-z0-9]/g, "");

        if (!raw) return "";

        /* a known field wins over any prefix, so educationLevel
           becomes class_level and not just "level" */

        if (SYNONYMS[raw]) return SYNONYMS[raw];

        let key = raw;

        /* strip a field prefix, longest first so "scholar" is
           removed before a stray "s" */

        const prefixes = PREFIXES.slice().sort(
            function (a, b) {
                return b.length - a.length;
            }
        );

        for (let i = 0; i < prefixes.length; i++) {

            const prefix = prefixes[i];

            if (
                key.length > prefix.length + 2 &&
                key.indexOf(prefix) === 0
            ) {

                const rest = key.slice(prefix.length);

                if (/^[a-z]{3}/.test(rest)) {

                    key = rest;
                    break;

                }

            }

        }

        key = key.replace(/([a-z0-9])([A-Z])/g, "$1_$2");

        const words = key.split("_").filter(Boolean);

        const camel = words.map(function (word) {
            return word.replace(
                /([a-z])([0-9])/g,
                "$1_$2"
            );
        });

        return SYNONYMS[key] ||
            SYNONYMS[camel.join("_")] ||
            camel.join("_");

    }

    function isSkipped(key, type) {

        if (!key) return true;

        if (SKIP_TYPES.indexOf(type) !== -1) return true;

        return SKIP_KEYS.indexOf(key) !== -1;

    }

    function clean(value) {

        const text = String(value === undefined || value === null
            ? ""
            : value)
            .replace(/\s+/g, " ")
            .trim();

        if (text.length > MAX_VALUE) {

            return text.slice(0, MAX_VALUE) + "...";

        }

        return text;

    }

    /* ---------- reading the form ---------- */

    function collect(form) {

        const payload = {};
        let count = 0;

        const fields = form.elements || [];

        for (let i = 0; i < fields.length; i++) {

            const field = fields[i];

            if (!field || !field.name && !field.id) continue;

            if (field.disabled) continue;

            const type = String(field.type || "").toLowerCase();

            /* radio and checkbox only count when chosen */

            if ((type === "radio" || type === "checkbox") && !field.checked) {
                continue;
            }

            const key = toKey(field.name || field.id);

            if (isSkipped(key, type)) continue;

            const value = clean(field.value);

            if (!value) continue;

            /* keep the first value for a repeated field */

            if (payload[key] === undefined) {

                payload[key] = value;
                count++;

            }

            if (count >= MAX_FIELDS) break;

        }

        return payload;

    }

    function firstValue(payload, keys) {

        for (let i = 0; i < keys.length; i++) {

            if (payload[keys[i]]) return payload[keys[i]];

        }

        return "";

    }

    function findEmail(form, payload) {

        const direct =
            form.querySelector(
                'input[type="email"]'
            );

        if (direct && direct.value) {

            return clean(direct.value);

        }

        return firstValue(payload, [
            "email",
            "email_address",
            "email_id"
        ]);

    }

    function findName(payload) {

        return firstValue(payload, [
            "name",
            "applicant_name",
            "full_name"
        ]);

    }

    function findMobile(payload) {

        return firstValue(payload, [
            "mobile",
            "phone",
            "contact"
        ]);

    }

    function findService(form) {

        const declared =
            form.getAttribute("data-yk-service");

        if (declared) return declared;

        if (SERVICES[form.id]) return SERVICES[form.id];

        const title = String(
            document.title || ""
        ).split("|")[0].trim();

        return title || "Portal form";

    }

    /* the id is usually rendered into the page by the page's own
       submit handler, which runs before this one */

    function findReference(form, payload) {

        if (payload.reference) return payload.reference;

        for (let i = 0; i < REFERENCE_IDS.length; i++) {

            const el =
                document.getElementById(REFERENCE_IDS[i]) ||
                form.querySelector(
                    "#" + REFERENCE_IDS[i]
                );

            if (el) {

                const value = clean(el.textContent);

                if (
                    value &&
                    value.length > 3 &&
                    value.toLowerCase() !==
                        "your reference number"
                ) {

                    return value;

                }

            }

        }

        return "";

    }

    /* ---------- public api ---------- */

    function resolveForm(formOrId) {

        if (typeof formOrId === "string") {

            return document.getElementById(formOrId);

        }

        return formOrId || null;

    }

    function buildPayload(form, extra) {

        const collected = collect(form);

        const payload = {
            form_id: form.id || "form",
            service: findService(form)
        };

        const name = findName(collected);
        const email = findEmail(form, collected);
        const mobile = findMobile(collected);

        if (name) payload.name = name;
        if (email) payload.email = email;
        if (mobile) payload.mobile = mobile;

        Object.keys(collected).forEach(function (key) {

            if (payload[key] === undefined) {

                payload[key] = collected[key];

            }

        });

        const reference = findReference(form, collected);

        if (reference) payload.reference = reference;

        /* values the page knows but the form does not show */

        if (extra) {

            Object.keys(extra).forEach(function (key) {

                const value = clean(extra[key]);

                if (value) payload[key] = value;

            });

        }

        if (!payload.email) delete payload.email;

        return payload;

    }

    return {

        /* Build the notification payload without sending it.
           Useful for debugging in the browser console. */

        payload: function (formOrId, extra) {

            const form = resolveForm(formOrId);

            return form ? buildPayload(form, extra) : null;

        },

        /* Send the notification. Never throws, never blocks the
           form: the record is already saved locally by the time
           this runs. Resolves { sent, reason }. */

        submit: function (formOrId, extra) {

            const form = resolveForm(formOrId);

            if (!form) {

                console.warn(
                    "Yuvakurazh 360: email-auth could not find the form",
                    formOrId
                );

                return Promise.resolve({
                    sent: false,
                    reason: "form-not-found"
                });

            }

            if (
                form.getAttribute("data-yk-email") === "off"
            ) {

                return Promise.resolve({
                    sent: false,
                    reason: "opted-out"
                });

            }

            let payload;

            try {

                payload = buildPayload(form, extra);

            } catch (error) {

                console.warn(
                    "Yuvakurazh 360: email-auth payload failed",
                    error
                );

                return Promise.resolve({
                    sent: false,
                    reason: "payload-failed"
                });

            }

            /* second copy of the same payload through Web3Forms,
               so the submission reaches an inbox even when
               EmailJS is not configured */

            if (window.YK_WEB3FORMS) {

                window.YK_WEB3FORMS.deliver(payload, form);

            }

            if (!window.YK_EMAIL) {

                return Promise.resolve({
                    sent: false,
                    reason: "helper-missing"
                });

            }

            return window.YK_EMAIL.send(
                form.id || "form",
                payload
            );

        }

    };

})();