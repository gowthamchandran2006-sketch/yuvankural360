/* =========================================================
   POLICE DEPARTMENT - SHARED CASE DATA
   Used by police-support.html (the four boxes) and
   police-cases.html (the case detail views), so both
   pages always show the same numbers.

   Status changes made on the dashboard are stored in
   "yuvaOfficerCases" and cases created with the New Case
   form in "policeNewCases", so both are merged in here.
   ========================================================= */

window.POLICE_VIEWS = [
    {
        key: "total",
        label: "Total Cases",
        short: "Total",
        hint: "Every case registered with the Police Department.",
        icon: "fa-solid fa-folder-open",
        color: "linear-gradient(135deg,#2563eb,#7c3aed)",
        status: null
    },
    {
        key: "pending",
        label: "Pending Cases",
        short: "Pending",
        hint: "Cases waiting for an officer to start the work.",
        icon: "fa-solid fa-clock",
        color: "linear-gradient(135deg,#f59e0b,#f97316)",
        status: "pending"
    },
    {
        key: "progress",
        label: "In Process",
        short: "In Process",
        hint: "Cases that an officer is actively handling.",
        icon: "fa-solid fa-spinner",
        color: "linear-gradient(135deg,#3b82f6,#0ea5e9)",
        status: "progress"
    },
    {
        key: "resolved",
        label: "Resolved Cases",
        short: "Resolved",
        hint: "Cases completed and closed by the department.",
        icon: "fa-solid fa-circle-check",
        color: "linear-gradient(135deg,#10b981,#059669)",
        status: "resolved"
    }
];


window.POLICE_STATUS_LABEL = {
    pending: "Pending",
    progress: "In Process",
    resolved: "Resolved",
    rejected: "Rejected"
};


window.POLICE_BASE_CASES = [
    {
        id: "IK360-1024",
        title: "Cyber Fraud Complaint",
        status: "pending",
        priority: "high",
        department: "Cyber Support",
        date: "28 Sep 2026",
        details: "Citizen reported a suspected online financial fraud and requested cyber support."
    },
    {
        id: "IK360-1018",
        title: "Document Verification Request",
        status: "progress",
        priority: "medium",
        department: "Revenue",
        date: "27 Sep 2026",
        details: "Application requires departmental verification before the next processing stage."
    },
    {
        id: "IK360-1009",
        title: "Scholarship Service Query",
        status: "pending",
        priority: "medium",
        department: "Education",
        date: "27 Sep 2026",
        details: "Student requested assistance regarding scholarship application status."
    },
    {
        id: "IK360-0998",
        title: "Citizen Safety Support",
        status: "progress",
        priority: "high",
        department: "Police Support",
        date: "26 Sep 2026",
        details: "Citizen submitted a safety-related support request requiring officer review."
    },
    {
        id: "IK360-0981",
        title: "Employment Service Request",
        status: "resolved",
        priority: "low",
        department: "Employment",
        date: "25 Sep 2026",
        details: "Citizen received information about employment and skill-development services."
    },
    {
        id: "IK360-0967",
        title: "Health Service Assistance",
        status: "resolved",
        priority: "medium",
        department: "Health",
        date: "24 Sep 2026",
        details: "Citizen was provided information regarding available health services."
    }
];


window.readPoliceStore = function (key) {

    try {
        return JSON.parse(
            localStorage.getItem(key)
        );
    } catch (e) {
        return null;
    }

};


/* every case the department knows about */

window.getPoliceCases = function () {

    const list =
        window.POLICE_BASE_CASES.map(function (item) {
            return Object.assign({}, item);
        });

    const overrides =
        window.readPoliceStore("yuvaOfficerCases") || {};

    list.forEach(function (item) {

        if (overrides[item.id])
            item.status = overrides[item.id];

    });


    const created =
        window.readPoliceStore("policeNewCases");

    if (Array.isArray(created)) {

        created
            .slice()
            .reverse()
            .forEach(function (record) {

                list.push({
                    id: record.id,
                    title: record.type,
                    status: overrides[record.id] || "pending",
                    priority: record.priority || "medium",
                    department: record.type,
                    date: record.date || "",
                    details:
                        "Reported by "
                        + record.name
                        + (
                            record.location
                                ? " (" + record.location + ")"
                                : ""
                        )
                        + ". "
                        + record.description,
                    isNew: true
                });

            });

    }


    list.sort(function (a, b) {
        return b.id.localeCompare(a.id);
    });


    return list;

};


window.countPoliceCases = function (status) {

    const all = window.getPoliceCases();

    if (!status)
        return all.length;

    return all.filter(function (item) {
        return item.status === status;
    }).length;

};