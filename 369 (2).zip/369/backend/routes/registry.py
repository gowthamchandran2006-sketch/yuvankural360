"""Government service registry: departments, offices and smart-routing lookup."""

from flask import Blueprint, jsonify, request

from core import resolve_service
from database import get_collection
from security import public

registry_bp = Blueprint("registry", __name__)


@registry_bp.get("")
def registry():
    departments = get_collection("departments").find()
    offices = get_collection("offices").find()
    services = get_collection("services").find()
    return jsonify({
        "departments": [public(d) for d in departments],
        "offices": [public(o) for o in offices],
        "services": [public(s) for s in services],
    })


@registry_bp.get("/departments")
def departments():
    rows = get_collection("departments").find()
    return jsonify({"count": len(rows), "departments": [public(d) for d in rows]})


@registry_bp.get("/offices")
def offices():
    dept = (request.args.get("department") or "").strip().upper()
    filt = {"departmentCode": dept} if dept else {}
    rows = get_collection("offices").find(filt)
    return jsonify({"count": len(rows), "offices": [public(o) for o in rows]})


@registry_bp.get("/routing")
def routing():
    query = (request.args.get("q") or "").strip()
    if not query:
        return jsonify({"error": "q query parameter is required"}), 400
    result = resolve_service(query)
    if not result.get("matched"):
        return jsonify({"matched": False, "message": result.get("message")}), 404
    return jsonify(result)