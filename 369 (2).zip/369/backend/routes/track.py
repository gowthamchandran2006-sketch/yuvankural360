"""Website usage tracking.

Every page load sends one small ping to /api/track/visit with a browser
generated visitor id and the page name. Nothing personal is collected: no
email, no IP, no user agent. Rows are keyed by visitor + page + day, so a
person who opens ten pages in a day still counts as one person, and the file
cannot grow without bound. The administrator console reads this collection to
answer "how many people used the website".
"""

from datetime import datetime, timedelta, timezone

from flask import Blueprint, jsonify, request

from database import get_collection
from security import now_iso

track_bp = Blueprint("track", __name__)

# how many days of history to keep
KEEP_DAYS = 90

# prune roughly once every this many new rows
PRUNE_EVERY = 40

_inserts = 0


def _today():
    return datetime.now(timezone.utc).date().isoformat()


def _prune(rows):
    """Drop rows older than KEEP_DAYS so visits.json stays small."""
    cutoff = (
        datetime.now(timezone.utc) - timedelta(days=KEEP_DAYS)
    ).date().isoformat()

    for row in rows.find():
        if str(row.get("day") or "") < cutoff:
            rows.delete_one({"_id": row.get("_id")})


@track_bp.post("/visit")
def visit():
    global _inserts

    data = request.get_json(silent=True) or {}

    page = str(data.get("page") or "").strip()[:120]
    visitor = str(data.get("visitor") or "").strip()[:64]

    if not page:
        return jsonify({"error": "page is required"}), 400

    if not visitor:
        visitor = str(
            request.headers.get("X-Visitor-Id") or ""
        ).strip()[:64]

    if not visitor:
        visitor = "anonymous"

    day = _today()
    rows = get_collection("visits")

    existing = rows.find_one(
        {"visitor": visitor, "page": page, "day": day}
    )

    if existing:
        rows.update_one(
            {"_id": existing.get("_id")},
            {
                "$set": {
                    "at": now_iso(),
                    "hits": int(existing.get("hits") or 1) + 1,
                }
            },
        )
        return jsonify({"ok": True, "counted": False})

    rows.insert_one(
        {
            "visitor": visitor,
            "page": page,
            "day": day,
            "at": now_iso(),
            "hits": 1,
        }
    )

    _inserts += 1
    if _inserts % PRUNE_EVERY == 0:
        _prune(rows)

    return jsonify({"ok": True, "counted": True})