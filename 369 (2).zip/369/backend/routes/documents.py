"""Document metadata management.

The frontend uploads document metadata (with optional base64 data). For a
production deployment, store files on disk/object storage and keep only the
reference here.
"""

from flask import Blueprint, jsonify, request

from database import get_collection
from security import now_iso, public, require_user

documents_bp = Blueprint("documents", __name__)


@documents_bp.post("")
@require_user
def upload_document(user, token):
    data = request.get_json(silent=True) or {}
    name = (data.get("name") or "").strip()
    doc_type = (data.get("type") or "general").strip()
    size = data.get("size")

    if not name:
        return jsonify({"error": "name is required"}), 400

    if data.get("dataUrl"):
        import base64
        payload = data["dataUrl"].split(",", 1)[-1]
        try:
            size = len(base64.b64decode(payload))
        except Exception:
            size = len(payload)

    doc = {
        "userId": user.get("email"),
        "name": name,
        "type": doc_type,
        "size": size,
        "createdAt": now_iso(),
    }
    result = get_collection("documents").insert_one(doc)
    doc["id"] = str(result.inserted_id)
    return jsonify(public(doc)), 201


@documents_bp.get("")
@require_user
def list_documents(user, token):
    rows = get_collection("documents").find({"userId": user.get("email")})
    return jsonify({"count": len(rows), "documents": [public(d) for d in rows]})


@documents_bp.delete("/<document_id>")
@require_user
def delete_document(user, token, document_id):
    result = get_collection("documents").delete_one(
        {"_id": document_id, "userId": user.get("email")}
    )
    if result.deleted_count == 0:
        return jsonify({"error": "Document not found"}), 404
    return jsonify({"message": "Document removed"})