"""Service discovery and eligibility guidance."""

from flask import Blueprint, jsonify, request

from database import get_collection
from security import public

services_bp = Blueprint("services", __name__)


@services_bp.get("")
def list_services():
    services = get_collection("services").find()
    return jsonify({"count": len(services), "services": [public(s) for s in services]})


@services_bp.get("/<service_id>")
def service_detail(service_id):
    try:
        service_id = int(service_id)
    except (TypeError, ValueError):
        pass
    service = get_collection("services").find_one({"_id": service_id})
    if not service:
        return jsonify({"error": "Service not found"}), 404
    return jsonify(public(service))


@services_bp.post("/eligibility-check")
def eligibility_check():
    """Guidance-only eligibility scoring using the user profile.

    Final eligibility and approval rest with the government authority.
    """
    data = request.get_json(silent=True) or {}
    profile = {
        "age": data.get("age"),
        "education": (data.get("education") or "").lower(),
        "occupation": (data.get("occupation") or "").lower(),
        "disability": bool(data.get("disability")),
    }
    matches = []

    for service in get_collection("services").find():
        score = 0
        hints = []
        eligibility = " ".join(service.get("eligibility", [])).lower()

        if "student" in eligibility or "pursuing" in eligibility:
            if profile["education"] and profile["education"] not in ("none", "no"):
                score += 1
                hints.append("Matches education criteria")
        if "age" in eligibility and profile["age"] is not None:
            try:
                if int(profile["age"]) >= 18:
                    score += 1
                    hints.append("Age seems eligible")
            except (TypeError, ValueError):
                pass
        if "disability" in eligibility and profile["disability"]:
            score += 1
            hints.append("Disability category matches")
        if "woman" in eligibility.lower() and profile["occupation"]:
            pass  # profile-based guidance only

        matches.append(
            {
                "service": service.get("service"),
                "name": service.get("name"),
                "score": score,
                "suggested": score >= 2,
                "hints": hints,
            }
        )

    matches.sort(key=lambda item: item["score"], reverse=True)
    return jsonify(
        {
            "matches": matches,
            "note": "Guidance only. Final eligibility and approval rest with the "
            "respective government authority or department.",
        }
    )