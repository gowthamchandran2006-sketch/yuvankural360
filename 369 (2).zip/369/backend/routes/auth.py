"""Auth routes: register, login, me, logout."""

from flask import Blueprint, jsonify, request

from database import get_collection
from security import generate_token, hash_password, now_iso, public, require_user, verify_password

auth_bp = Blueprint("auth", __name__)


def _create_session(user):
    """Start a session for a user.

    Sessions keep the user id because an OTP signed in citizen may
    not have an email address, so email alone is not a safe key.
    """
    token = generate_token()
    get_collection("sessions").insert_one(
        {
            "token": token,
            "user_id": user.get("_id"),
            "email": user.get("email") or "",
            "mobile": user.get("mobile") or "",
            "created_at": now_iso(),
        }
    )
    return token


@auth_bp.post("/register")
def register():
    data = request.get_json(silent=True) or {}
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip().lower()
    mobile = (data.get("mobile") or "").strip()
    password = data.get("password") or ""

    if not name or not email or not password:
        return jsonify({"error": "name, email and password are required"}), 400
    # the sign-up form no longer asks for a mobile number, so it is
    # optional here; when one is sent it still has to be 10 digits
    if mobile and (len(mobile) != 10 or not mobile.isdigit()):
        return jsonify({"error": "Mobile number must be 10 digits"}), 400
    if len(password) < 6:
        return jsonify({"error": "Password must be at least 6 characters"}), 400

    users = get_collection("users")
    # an empty mobile must not match the accounts that already have one
    lookup = [{"email": email}]
    if mobile:
        lookup.append({"mobile": mobile})

    existing = users.find_one({"$or": lookup})
    if existing:
        return jsonify({"error": "An account with this email or mobile already exists"}), 409

    user = {
        "name": name,
        "email": email,
        "mobile": mobile,
        "password": hash_password(password),
        "role": "citizen",
        "created_at": now_iso(),
    }
    # insert_one copies the document, so the id has to come from its
    # return value or the session ends up pointing at nothing.
    user["_id"] = users.insert_one(user).inserted_id

    token = _create_session(user)
    return jsonify({"token": token, "user": public(user)}), 201


@auth_bp.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    identifier = (data.get("user") or "").strip().lower()
    password = data.get("password") or ""

    if not identifier or not password:
        return jsonify({"error": "User and password are required"}), 400

    users = get_collection("users")
    user = users.find_one(
        {"$or": [{"email": identifier}, {"mobile": identifier}]}
    )
    if not user or not verify_password(password, user.get("password")):
        return jsonify({"error": "Invalid email/mobile or password"}), 401

    token = _create_session(user)
    return jsonify({"token": token, "user": public(user)})


@auth_bp.get("/me")
@require_user
def me(user, token):
    return jsonify({"user": public(user)})


@auth_bp.post("/change-password")
@require_user
def change_password(user, token):
    data = request.get_json(silent=True) or {}
    current = data.get("currentPassword") or ""
    new = data.get("newPassword") or ""
    confirm = data.get("confirmPassword") or ""

    if not current or not new:
        return jsonify({"error": "Current and new password are required"}), 400
    if len(new) < 6:
        return jsonify({"error": "New password must be at least 6 characters"}), 400
    if confirm and new != confirm:
        return jsonify({"error": "Passwords do not match"}), 400
    if current == new:
        return jsonify(
            {"error": "New password must be different from the current one"}
        ), 400
    if not verify_password(current, user.get("password")):
        return jsonify({"error": "Current password is incorrect"}), 401

    get_collection("users").update_one(
        {"_id": user["_id"]},
        {"$set": {"password": hash_password(new), "password_changed_at": now_iso()}},
    )

    # every other device has to sign in again with the new password; the
    # file store only understands plain matches, so drop them one by one
    sessions = get_collection("sessions")
    for row in sessions.find({"user_id": user["_id"]}):
        if row.get("token") != token:
            sessions.delete_one({"token": row.get("token")})

    return jsonify({"message": "Password updated successfully"})


@auth_bp.post("/logout")
@require_user
def logout(user, token):
    get_collection("sessions").delete_one({"token": token})
    return jsonify({"message": "Logged out successfully"})