"""Administrator console: one unique email + password opens frontend/admin.html.

The pair lives in backend/config.py (ADMIN_EMAIL / ADMIN_PASSWORD). seed.py
stores it hashed in the `admins` collection, so the plaintext password is
never written to disk or returned by the API. A correct sign-in returns a
token carrying scope "admin"; every other endpoint here requires it, so the
page cannot be used by a citizen or a department officer.
"""

from datetime import datetime, timedelta, timezone

from flask import Blueprint, jsonify, request

from core import enrich, sla_state
from database import get_collection
from security import generate_token, now_iso, public, require_admin, verify_password

admin_bp = Blueprint("admin", __name__)

# (email, timestamp) of recent failed sign-ins, used to slow guessing down.
_FAILURES = []
MAX_FAILURES = 5
LOCK_MINUTES = 10


def _recent_failures(email):
    cutoff = datetime.now(timezone.utc) - timedelta(minutes=LOCK_MINUTES)
    return [
        stamp
        for addr, stamp in _FAILURES
        if addr == email and stamp > cutoff
    ]


def _record_failure(email):
    _FAILURES.append((email, datetime.now(timezone.utc)))


@admin_bp.post("/login")
def admin_login():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    if not email or not password:
        return jsonify({"error": "Email and password are required"}), 400

    if len(_recent_failures(email)) >= MAX_FAILURES:
        return jsonify({
            "error": "Too many failed attempts. Try again in a few minutes."
        }), 429

    admin = get_collection("admins").find_one({"email": email})
    if not admin or not verify_password(password, admin.get("password")):
        _record_failure(email)
        return jsonify({"error": "Invalid administrator credentials"}), 401

    del _FAILURES[:]

    token = generate_token()
    get_collection("sessions").insert_one(
        {
            "token": token,
            "email": email,
            "scope": "admin",
            "role": admin.get("role", "administrator"),
            "created_at": now_iso(),
        }
    )

    return jsonify({"token": token, "admin": public(admin)})


@admin_bp.post("/logout")
@require_admin
def admin_logout(user, admin):
    auth = request.headers.get("Authorization", "")
    token = auth.split(" ", 1)[1].strip() if auth.startswith("Bearer ") else ""
    if token:
        get_collection("sessions").delete_one({"token": token})
    return jsonify({"message": "Signed out"})


@admin_bp.get("/overview")
@require_admin
def overview(user, admin):
    """Everything the console shows, counted straight from the collections."""

    users = get_collection("users")
    cases = get_collection("cases")
    applications = get_collection("applications")
    complaints = get_collection("complaints")

    all_cases = list(cases.find())

    def by_status(*wanted):
        return sum(1 for c in all_cases if c.get("status") in wanted)

    sla = {"nearing": 0, "breached": 0}
    for case in all_cases:
        if case.get("status") in ("Approved", "Rejected", "Resolved"):
            continue
        state = sla_state(case)["state"]
        if state in sla:
            sla[state] += 1

    recent_cases = sorted(
        all_cases,
        key=lambda c: c.get("createdAt") or "",
        reverse=True,
    )[:8]

    recent_audit = sorted(
        get_collection("audit").find(),
        key=lambda a: a.get("at") or a.get("created_at") or "",
        reverse=True,
    )[:8]

    return jsonify(
        {
            "admin": {
                "email": admin.get("email"),
                "name": admin.get("name"),
                "role": admin.get("role"),
            },
            "totals": {
                "users": users.count_documents({}),
                "officers": get_collection("officers").count_documents({}),
                "admins": get_collection("admins").count_documents({}),
                "cases": len(all_cases),
                "applications": applications.count_documents({}),
                "complaints": complaints.count_documents({}),
                "services": get_collection("services").count_documents({}),
                "departments": get_collection("departments").count_documents({}),
                "offices": get_collection("offices").count_documents({}),
                "notifications": get_collection("notifications").count_documents({}),
            },
            "cases": {
                "total": len(all_cases),
                "pending": by_status("Submitted", "Department Handover", "Pending"),
                "processing": by_status("Processing"),
                "approved": by_status("Approved"),
                "rejected": by_status("Rejected"),
                "resolved": by_status("Resolved"),
                "escalated": sum(1 for c in all_cases if c.get("escalated")),
                "slaNearing": sla["nearing"],
                "slaBreached": sla["breached"],
            },
            "applications": {
                "total": applications.count_documents({}),
                "applied": applications.count_documents({"status": "Applied"}),
                "approved": applications.count_documents({"status": "Approved"}),
                "rejected": applications.count_documents({"status": "Rejected"}),
            },
            "complaints": {
                "total": complaints.count_documents({}),
                "open": complaints.count_documents({"status": "Open"}),
                "closed": complaints.count_documents(
                    {"status": {"$in": ["Closed", "Resolved"]}}
                ),
            },
            "recentCases": [public(enrich(c)) for c in recent_cases],
            "recentAudit": [public(a) for a in recent_audit],
            "usage": usage_report(),
            "generatedAt": now_iso(),
        }
    )


# ---------- helpers shared by the overview and the list endpoints ----------


def _day(value):
    """First 10 characters of an ISO stamp, which is the UTC day."""
    return str(value or "")[:10]


def usage_report():
    """How many people used the website, and how often.

    Visits come from the `visits` collection that /api/track/visit fills in.
    A person counts once per day, so opening five pages does not read as
    five different users.
    """

    now = datetime.now(timezone.utc)
    today = now.date().isoformat()
    week = (now - timedelta(days=7)).date().isoformat()

    visits = list(get_collection("visits").find())
    sessions = list(get_collection("sessions").find())
    people = list(get_collection("users").find())

    people_sessions = [
        s for s in sessions if s.get("scope") != "admin"
    ]

    pages = {}
    for row in visits:
        page = row.get("page") or "unknown"
        pages[page] = pages.get(page, 0) + int(row.get("hits") or 1)

    return {
        "visitors": len({v.get("visitor") for v in visits}),
        "visitorsToday": len(
            {v.get("visitor") for v in visits if v.get("day") == today}
        ),
        "visitors7d": len(
            {
                v.get("visitor")
                for v in visits
                if str(v.get("day") or "") >= week
            }
        ),
        "pageViews": sum(int(v.get("hits") or 1) for v in visits),
        "pagesTracked": len(pages),
        "logins": len(people_sessions),
        "loginsToday": sum(
            1 for s in people_sessions if _day(s.get("created_at")) == today
        ),
        "registeredUsers": len(people),
        "newUsersToday": sum(
            1 for p in people if _day(p.get("created_at")) == today
        ),
        "newUsers7d": sum(
            1 for p in people if _day(p.get("created_at")) >= week
        ),
        "topPages": [
            {"page": page, "views": views}
            for page, views in sorted(
                pages.items(), key=lambda pair: pair[1], reverse=True
            )[:8]
        ],
        "since": min(
            [_day(v.get("day")) for v in visits if v.get("day")] or [today]
        ),
    }


def _limit(raw, fallback=25, ceiling=200):
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return fallback
    return max(1, min(ceiling, value))


def _search_term():
    return str(request.args.get("q") or "").strip().lower()


def _matches(doc, term, fields):
    if not term:
        return True
    for field in fields:
        value = doc.get(field)
        if value is None:
            continue
        if term in str(value).lower():
            return True
    return False


@admin_bp.get("/cases")
@require_admin
def case_list(user, admin):
    """Every case, newest first, with an optional status filter and search."""

    status = str(request.args.get("status") or "").strip()
    term = _search_term()
    limit = _limit(request.args.get("limit"))

    rows = list(get_collection("cases").find())
    if status:
        rows = [c for c in rows if c.get("status") == status]

    rows = [
        c
        for c in rows
        if _matches(
            c,
            term,
            ["id", "title", "type", "name", "citizenName", "location",
             "description", "department"],
        )
    ]

    rows.sort(
        key=lambda c: str(c.get("createdAt") or c.get("created_at") or ""),
        reverse=True,
    )

    return jsonify(
        {
            "total": len(rows),
            "shown": min(limit, len(rows)),
            "cases": [public(enrich(c)) for c in rows[:limit]],
        }
    )


@admin_bp.get("/people")
@require_admin
def people_list(user, admin):
    """Registered citizens and department officers, with usage numbers."""

    term = _search_term()
    limit = _limit(request.args.get("limit"))

    people = [
        p
        for p in get_collection("users").find()
        if _matches(p, term, ["name", "email", "mobile"])
    ]
    officers = [
        o
        for o in get_collection("officers").find()
        if _matches(o, term, ["name", "email", "mobile", "rank", "department"])
    ]

    people.sort(key=lambda p: str(p.get("created_at") or ""), reverse=True)
    officers.sort(key=lambda o: str(o.get("name") or ""))

    return jsonify(
        {
            "users": len(people),
            "officers": len(officers),
            "people": [public(p) for p in people[:limit]],
            "officerList": [public(o) for o in officers[:limit]],
        }
    )


@admin_bp.get("/applications")
@require_admin
def application_list(user, admin):
    status = str(request.args.get("status") or "").strip()
    term = _search_term()
    limit = _limit(request.args.get("limit"))

    rows = list(get_collection("applications").find())
    if status:
        rows = [a for a in rows if a.get("status") == status]

    rows = [
        a
        for a in rows
        if _matches(a, term, ["id", "name", "service", "scheme", "email"])
    ]

    rows.sort(key=lambda a: str(a.get("createdAt") or a.get("created_at") or ""), reverse=True)

    return jsonify(
        {
            "total": len(rows),
            "shown": min(limit, len(rows)),
            "applications": [public(enrich(a)) for a in rows[:limit]],
        }
    )


@admin_bp.get("/complaints")
@require_admin
def complaint_list(user, admin):
    status = str(request.args.get("status") or "").strip()
    term = _search_term()
    limit = _limit(request.args.get("limit"))

    rows = list(get_collection("complaints").find())
    if status:
        rows = [c for c in rows if c.get("status") == status]

    rows = [
        c
        for c in rows
        if _matches(c, term, ["id", "name", "subject", "email", "category"])
    ]

    rows.sort(key=lambda c: str(c.get("createdAt") or c.get("created_at") or ""), reverse=True)

    return jsonify(
        {
            "total": len(rows),
            "shown": min(limit, len(rows)),
            "complaints": [public(enrich(c)) for c in rows[:limit]],
        }
    )