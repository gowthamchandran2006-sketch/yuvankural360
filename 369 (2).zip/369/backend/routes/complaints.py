"""Complaint / grievance registration with existing-case linking and
duplicate-complaint detection."""

import re

from flask import Blueprint, jsonify, request

from core import audit, detect_duplicates
from database import get_collection
from security import now_iso, public, require_officer, require_user

complaints_bp = Blueprint("complaints", __name__)


@complaints_bp.post("")
@require_user
def create_complaint(user, token):
    data = request.get_json(silent=True) or {}
    subject = (data.get("subject") or "").strip()
    message = (data.get("message") or "").strip()
    link_case = (data.get("caseId") or "").strip().upper()
    mobile = str(data.get("mobile") or user.get("mobile") or "").strip()

    if not subject or not message:
        return jsonify({"error": "subject and message are required"}), 400
    if not re.fullmatch(r"\d{10}", mobile):
        return jsonify({"error": "Mobile number must be 10 digits"}), 400

    linked_case = None
    if link_case:
        linked_case = get_collection("cases").find_one({"caseId": link_case})
        if not linked_case or linked_case.get("userId") != user.get("email"):
            return jsonify({"error": "Linked case not found or not owned by you"}), 400
    else:
        # existing-application detection: match an open journey for the same citizen
        for case in get_collection("cases").find({"userId": user.get("email")}):
            combined = f"{case.get('serviceName')} {case.get('service')}"
            if any(term in message.lower() for term in combined.lower().split() if len(term) > 3):
                linked_case = case
                break
    # fall back to a service-route match using the registry keywords
    if linked_case is None:
        from core import resolve_service
        route = resolve_service(message)
        if route.get("matched"):
            for case in get_collection("cases").find({"userId": user.get("email")}):
                if case.get("service") == route.get("service") and case.get("status") not in ("Approved", "Rejected", "Resolved"):
                    linked_case = case
                    break

    duplicate = detect_duplicates(user.get("email"), f"{subject} {message}", link_case)

    complaint = {
        "userId": user.get("email"),
        "complaintId": f"GRV-{now_iso()[:4]}-{get_collection('complaints').count_documents({}) + 1:06d}",
        "subject": subject,
        "message": message,
        "mobile": mobile,
        "caseId": linked_case.get("caseId") if linked_case else None,
        "linkedStatus": linked_case.get("status") if linked_case else None,
        "duplicate": duplicate,
        "status": "Open",
        "createdAt": now_iso(),
    }
    result = get_collection("complaints").insert_one(complaint)
    complaint["id"] = str(result.inserted_id)

    if linked_case:
        message_text = (
            f"Your complaint {complaint['complaintId']} is linked to case {linked_case['caseId']} "
            f"(current status: {linked_case.get('status')}) and will be handled with it."
        )
    else:
        message_text = f"Your complaint {complaint['complaintId']} has been registered."
    get_collection("notifications").insert_one(
        {"userId": user.get("email"), "type": "complaint.registered",
         "message": message_text, "caseId": complaint["caseId"], "read": False, "createdAt": now_iso()}
    )
    audit(user.get("email"), user.get("role", "citizen"), "complaint.create",
          case_id=complaint["caseId"], detail=f"{subject} | duplicate={bool(duplicate)}")
    return jsonify(public(complaint)), 201


@complaints_bp.get("")
@require_user
def list_complaints(user, token):
    rows = get_collection("complaints").find({"userId": user.get("email")})
    return jsonify({"count": len(rows), "complaints": [public(c) for c in rows]})


@complaints_bp.patch("/<complaint_id>/status")
@require_officer
def update_complaint_status(user, officer, complaint_id):
    data = request.get_json(silent=True) or {}
    status = (data.get("status") or "").strip()
    allowed = {"Open", "In Progress", "Resolved", "Closed"}
    if status not in allowed:
        return jsonify({"error": f"Status must be one of: {sorted(allowed)}"}), 400

    complaint = get_collection("complaints").find_one({"_id": complaint_id})
    result = get_collection("complaints").update_one(
        {"_id": complaint_id},
        {"$set": {"status": status, "updatedAt": now_iso(), "officer": user.get("email")}},
    )
    if result.modified_count == 0:
        return jsonify({"error": "Complaint not found"}), 404
    if complaint and complaint.get("caseId"):
        from core import add_history
        add_history(complaint["caseId"], "Processing" if status in ("In Progress",) else "Pending",
                    note=f"Complaint {complaint.get('complaintId')} -> {status}", by=user.get("email"), via="officer")
    audit(user.get("email"), user.get("role", "officer"), "complaint.status",
          case_id=complaint.get("caseId") if complaint else None, detail=f"-> {status}")
    return jsonify({"message": "Status updated", "status": status})