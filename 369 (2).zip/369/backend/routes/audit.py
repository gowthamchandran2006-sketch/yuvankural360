"""Audit trail: who did what, when, to which case, in which department."""

from flask import Blueprint, jsonify, request

from database import get_collection
from security import public, require_officer

audit_bp = Blueprint("audit", __name__)


@audit_bp.get("")
@require_officer
def audit_log(user, officer):
    case_id = (request.args.get("caseId") or "").strip().upper()
    actor = (request.args.get("actor") or "").strip().lower()
    filt = {}
    if case_id:
        filt["caseId"] = case_id
    if actor:
        filt["actor"] = actor
    rows = get_collection("audit").find(filt)
    rows.sort(key=lambda a: a.get("at") or "", reverse=True)
    return jsonify({"count": len(rows), "entries": [public(a) for a in rows]})