"""Officer dashboard: SLA-aware statistics, case queue, AI-assisted summaries.

RBAC: system_admin sees everything; a department officer only sees cases for
their department. AI assists (summary / priority / SLA risk) but never decides.
"""

from flask import Blueprint, jsonify, request

from core import enrich, sla_state
from database import get_collection
from security import (
    generate_token,
    now_iso,
    public,
    require_officer,
    verify_password,
)

officers_bp = Blueprint("officers", __name__)


def _department_scope(officer):
    if officer.get("role") == "system_admin":
        return None
    return officer.get("departmentCode") or officer.get("department")


def _scoped_case_iter(officer):
    scope = _department_scope(officer)
    for case in get_collection("cases").find():
        if scope:
            if case.get("departmentCode") != scope and case.get("department") != scope:
                continue
        yield case


@officers_bp.post("/login")
def officer_login():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    officer = get_collection("officers").find_one({"email": email})
    if not officer or not verify_password(password, officer.get("password")):
        return jsonify({"error": "Invalid officer credentials"}), 401

    token = generate_token()
    get_collection("sessions").insert_one(
        {"token": token, "email": email, "created_at": now_iso()}
    )
    return jsonify({"token": token, "officer": public(officer)})


@officers_bp.get("/stats")
@require_officer
def stats(user, officer):
    applications = get_collection("applications")
    complaints = get_collection("complaints")
    cases = get_collection("cases")
    users = get_collection("users")

    scope = _department_scope(officer)

    def count_cases(pred=None):
        n = 0
        for case in _scoped_case_iter(officer):
            if pred is None or pred(case):
                n += 1
        return n

    total = count_cases()
    pending = count_cases(lambda c: c.get("status") in ("Submitted", "Department Handover", "Pending"))
    processing = count_cases(lambda c: c.get("status") == "Processing")
    approved = count_cases(lambda c: c.get("status") == "Approved")
    rejected = count_cases(lambda c: c.get("status") == "Rejected")
    resolved = count_cases(lambda c: c.get("status") == "Resolved")
    escalated_cases = count_cases(lambda c: bool(c.get("escalated")) or c.get("status") == "Escalated")

    sla_nearing = 0
    sla_breached = 0
    for case in _scoped_case_iter(officer):
        if case.get("status") in ("Approved", "Rejected", "Resolved"):
            continue
        state = sla_state(case)["state"]
        if state == "nearing":
            sla_nearing += 1
        elif state == "breached":
            sla_breached += 1

    return jsonify({
        "scope": "system" if scope is None else scope,
        "applications": applications.count_documents({}),
        "applicationsPending": applications.count_documents({"status": "Applied"}),
        "complaints": complaints.count_documents({}),
        "complaintsPending": complaints.count_documents({"status": "Open"}),
        "users": users.count_documents({}),
        "cases": total,
        "casesPending": pending,
        "casesProcessing": processing,
        "casesApproved": approved,
        "casesRejected": rejected,
        "casesResolved": resolved,
        "slaNearing": sla_nearing,
        "slaBreached": sla_breached,
        "escalated": escalated_cases,
    })


@officers_bp.get("/pending")
@require_officer
def pending(user, officer):
    return jsonify({
        "cases": [
            public(enrich(c))
            for c in sorted(_scoped_case_iter(officer), key=lambda c: c.get("createdAt") or "", reverse=True)
            if c.get("status") in ("Submitted", "Department Handover", "Pending", "Processing", "Document Required")
        ],
        "applications": [public(a) for a in get_collection("applications").find({"status": "Applied"})],
        "complaints": [public(c) for c in get_collection("complaints").find({"status": "Open"})],
    })


@officers_bp.get("/cases")
@require_officer
def case_queue(user, officer):
    """Full scoped case queue with SLA/priority for the officer dashboard."""
    cases = []
    for case in _scoped_case_iter(officer):
        cases.append(public(enrich(case)))
    cases.sort(key=lambda c: {"High": 0, "Medium": 1, "Low": 2}.get(c.get("priority"), 3))
    return jsonify({"count": len(cases), "cases": cases})


@officers_bp.post("/case/update")
@require_officer
def update_case(user, officer):
    """Officer-driven case status/handover via one endpoint."""
    data = request.get_json(silent=True) or {}
    case_id = (data.get("caseId") or "").strip().upper()
    action = (data.get("action") or "status").strip()
    value = (data.get("value") or data.get("status") or "").strip()
    note = (data.get("note") or "").strip()

    case = get_collection("cases").find_one({"caseId": case_id})
    if not case:
        return jsonify({"error": "Case not found"}), 404
    scope = _department_scope(officer)
    if scope and case.get("departmentCode") != scope:
        return jsonify({"error": "Case not in your department scope"}), 403

    from core import add_history, audit
    if action == "handover":
        department = (data.get("department") or case.get("department") or "").strip()
        office = (data.get("office") or case.get("office") or "").strip()
        get_collection("cases").update_one({"caseId": case_id}, {"$set": {
            "department": department, "office": office, "status": "Department Handover", "updatedAt": now_iso()}})
        updated = add_history(case_id, "Department Handover", note=note or f"Handed over to {department}/{office}",
                              by=user.get("email"), via="handover")
        audit(user.get("email"), user.get("role", "officer"), "case.handover", case_id=case_id,
              service=case.get("service"), detail=f"{department}/{office}: {note}")
    else:
        if not value:
            return jsonify({"error": "value (status) is required"}), 400
        from core import CASE_STATUSES
        if value not in CASE_STATUSES:
            return jsonify({"error": f"Invalid status. Allowed: {CASE_STATUSES}"}), 400
        updated = add_history(case_id, value, note=note, by=user.get("email"), via="officer")
        if value == "Escalated" and not note:
            get_collection("cases").update_one({"caseId": case_id}, {"$set": {"escalated": True, "escalatedAt": now_iso()}})
            updated = get_collection("cases").find_one({"caseId": case_id})
        audit(user.get("email"), user.get("role", "officer"), "case.update", case_id=case_id,
              service=case.get("service"), detail=f"-> {value}: {note}")
    return jsonify({"message": "Case updated", "case": public(enrich(updated))})


@officers_bp.post("/case-summary")
@require_officer
def case_summary(user, officer):
    """AI-assisted case summary: reads the case + history and produces a short
    human-readable brief, urgency indication and SLA risk. No decisions."""
    data = request.get_json(silent=True) or {}
    case_id = (data.get("caseId") or "").strip().upper()
    case = get_collection("cases").find_one({"caseId": case_id})
    if not case:
        return jsonify({"error": "Case not found"}), 404

    sla = sla_state(case)
    history = case.get("history", []) or []
    latest = history[-1] if history else {}

    urgency = "High" if sla["state"] == "breached" or case.get("escalated") else (
        "Medium" if sla["state"] == "nearing" else "Low")
    summary_lines = [
        f"{case.get('serviceName') or case.get('service')} requested by {case.get('applicantName')} "
        f"(case {case['caseId']})."
    ]
    if case.get("applicantMobile"):
        summary_lines.append(f"Contact: {case['applicantMobile']}.")
    summary_lines.append(
        f"Currently \"{case.get('status')}\" at {case.get('office') or case.get('department')} "
        f"({case.get('department')})."
    )
    if sla["state"] != "no_sla":
        summary_lines.append(
            f"SLA: {sla['progress']}% elapsed, deadline {sla['deadline'][:10]}, "
            f"state={sla['state']}, remaining {sla['remaining']} day(s)."
        )
    else:
        summary_lines.append("SLA: not applicable for this service.")
    if case.get("escalated"):
        summary_lines.append("Escalation flag set — requires higher-authority attention.")
    summary_lines.append(f"Last event: {latest.get('status')}" + (f" — {latest.get('note')}" if latest.get("note") else "") + ".")

    return jsonify({
        "caseId": case_id,
        "summary": " ".join(summary_lines),
        "urgency": urgency,
        "slaRisk": sla["state"],
        "priority": {"High": 0, "Medium": 1, "Low": 2}[urgency],
        "flaggedDuplicateInfo": bool(case.get("escalated")),
        "case": public(enrich(case)),
    })