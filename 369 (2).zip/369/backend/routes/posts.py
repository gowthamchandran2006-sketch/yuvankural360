"""Community posts shown in the dashboard feed.

A signed in citizen can publish a short update, optionally with one photo and
optionally locked to "just me". Posts carry the author's name and user id,
never their email, so a post can be attributed without exposing the address
behind it.

Photos are written to disk under Config.UPLOAD_DIR and only the filename is
stored on the post, so posts.json stays small.
"""

import base64
import binascii
import os
import re
import secrets
import time

from flask import Blueprint, jsonify, request, send_from_directory

from config import Config
from database import get_collection
from security import now_iso, public, require_user

posts_bp = Blueprint("posts", __name__)

# guards so one request cannot fill the file store
MAX_POSTS = 500
MAX_TEXT = 1000
MAX_TITLE = 120
MAX_CATEGORY = 60

CATEGORIES = (
    "General",
    "Scholarship",
    "Employment",
    "Welfare",
    "Women & Child",
    "Police",
    "Feedback",
)

VISIBILITIES = ("public", "private")

# only real image bytes are accepted, and the extension is chosen from the
# sniffed type rather than from whatever the browser called the file
PHOTO_TYPES = {
    "jpeg": "jpg",
    "png": "png",
    "webp": "webp",
    "gif": "gif",
}

_MAGIC = (
    (b"\xff\xd8\xff", "jpeg"),
    (b"\x89PNG\r\n\x1a\n", "png"),
    (b"GIF87a", "gif"),
    (b"GIF89a", "gif"),
)


def post_id_for(post_id):
    """Ids are handed out as strings but stored as ints in the file store."""
    try:
        return int(post_id)
    except (TypeError, ValueError):
        return post_id


def sniff_photo(raw):
    """Return the image kind, or None when the bytes are not an image."""
    for magic, kind in _MAGIC:
        if raw.startswith(magic):
            return kind
    if raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        return "webp"
    return None


def photo_dir():
    os.makedirs(Config.UPLOAD_DIR, exist_ok=True)
    return Config.UPLOAD_DIR


def _safe_name(name):
    """Never build a path from user input."""
    return re.sub(r"[^A-Za-z0-9_.-]", "", str(name or ""))[:80]


def can_see(post, user):
    """A private post is visible only to its author."""
    if post.get("visibility") != "private":
        return True
    return str(post.get("authorId")) == str(user.get("_id"))


@posts_bp.get("")
@require_user
def list_posts(user, token):
    """Newest first. Paged with ?limit and ?before."""
    rows = get_collection("posts").find()

    visible = [p for p in rows if can_see(p, user)]

    visible.sort(key=lambda p: p.get("createdAt") or "", reverse=True)

    limit = request.args.get("limit")
    try:
        limit = max(1, min(int(limit), MAX_POSTS)) if limit else 50
    except (TypeError, ValueError):
        limit = 50

    before = request.args.get("before") or ""
    if before:
        visible = [p for p in visible if (p.get("createdAt") or "") < before]

    return jsonify({"count": len(visible[:limit]), "posts": [public(p) for p in visible[:limit]]})


@posts_bp.post("")
@require_user
def create_post(user, token):
    data = request.get_json(silent=True) or {}

    body = (data.get("body") or "").strip()
    title = (data.get("title") or "").strip()[:MAX_TITLE]
    category = (data.get("category") or "General").strip()[:MAX_CATEGORY]
    visibility = (data.get("visibility") or "public").strip().lower()

    if not title:
        return jsonify({"error": "A title is required"}), 400
    if not body and not data.get("photo"):
        return jsonify({"error": "Write something or add a photo before posting"}), 400
    if len(body) > MAX_TEXT:
        return jsonify({"error": f"A post can be at most {MAX_TEXT} characters"}), 400
    if category not in CATEGORIES:
        category = "General"
    if visibility not in VISIBILITIES:
        visibility = "public"

    post = {
        "authorId": str(user.get("_id")),
        "authorName": (user.get("name") or "Citizen").strip() or "Citizen",
        "title": title,
        "category": category,
        "visibility": visibility,
        "body": body,
        "photo": None,
        "likes": 0,
        "likedBy": [],
        "createdAt": now_iso(),
    }

    data_url = data.get("photo")
    if data_url:
        try:
            post["photo"] = save_photo(data_url)
        except ValueError as exc:
            return jsonify({"error": str(exc)}), 400

    posts = get_collection("posts")

    # keep the file store from growing without bound, and take the photos
    # of anything that gets dropped with it
    existing = posts.find()
    if len(existing) >= MAX_POSTS:
        existing.sort(key=lambda p: p.get("createdAt") or "")
        oldest = existing[0]
        posts.delete_one({"_id": oldest.get("_id")})
        drop_photo(oldest.get("photo"))

    result = posts.insert_one(post)
    post["id"] = str(result.inserted_id)
    return jsonify({"post": public(post)}), 201


def save_photo(data_url):
    """Store one data-URL image and return the filename."""
    if not isinstance(data_url, str) or "," not in data_url:
        raise ValueError("The photo could not be read")

    payload = data_url.split(",", 1)[1]

    try:
        raw = base64.b64decode(payload, validate=True)
    except (binascii.Error, ValueError):
        raise ValueError("The photo could not be read")

    if not raw:
        raise ValueError("The photo is empty")
    if len(raw) > Config.MAX_PHOTO_BYTES:
        limit = Config.MAX_PHOTO_BYTES // (1024 * 1024)
        raise ValueError(f"A photo can be at most {limit} MB")

    kind = sniff_photo(raw)
    if not kind:
        raise ValueError("Only JPG, PNG, WebP or GIF photos are allowed")

    name = f"post_{int(time.time())}_{secrets.token_hex(8)}.{PHOTO_TYPES[kind]}"

    with open(os.path.join(photo_dir(), name), "wb") as handle:
        handle.write(raw)

    return name


def drop_photo(name):
    safe = _safe_name(name)
    if not safe:
        return
    try:
        os.remove(os.path.join(photo_dir(), safe))
    except OSError:
        pass


@posts_bp.get("/photo/<path:name>")
@require_user
def get_photo(user, token, name):
    """Serve a post photo, but only to someone allowed to see the post."""
    safe = _safe_name(name)

    owner = None
    for post in get_collection("posts").find():
        if post.get("photo") and _safe_name(post["photo"]) == safe:
            owner = post
            break

    if not owner or not can_see(owner, user):
        return jsonify({"error": "Photo not found"}), 404

    return send_from_directory(photo_dir(), safe)


@posts_bp.post("/<post_id>/like")
@require_user
def toggle_like(user, token, post_id):
    """Flip this citizen's like on a post. One person, one like."""
    post = get_collection("posts").find_one({"_id": post_id_for(post_id)})
    if not post:
        return jsonify({"error": "Post not found"}), 404
    if not can_see(post, user):
        return jsonify({"error": "Post not found"}), 404

    liker = str(user.get("_id"))
    liked_by = [str(x) for x in (post.get("likedBy") or [])]

    if liker in liked_by:
        liked_by = [x for x in liked_by if x != liker]
        liked = False
    else:
        liked_by.append(liker)
        liked = True

    get_collection("posts").update_one(
        {"_id": post.get("_id")},
        {"$set": {"likedBy": liked_by, "likes": len(liked_by)}},
    )

    return jsonify({"id": str(post.get("_id")), "liked": liked, "likes": len(liked_by)})


@posts_bp.delete("/<post_id>")
@require_user
def delete_post(user, token, post_id):
    """Only the author may remove their post."""
    posts = get_collection("posts")
    post = posts.find_one({"_id": post_id_for(post_id)})

    if not post:
        return jsonify({"error": "Post not found"}), 404
    if str(post.get("authorId")) != str(user.get("_id")):
        return jsonify({"error": "You can only delete your own posts"}), 403

    posts.delete_one({"_id": post.get("_id")})
    drop_photo(post.get("photo"))

    return jsonify({"message": "Post deleted"})