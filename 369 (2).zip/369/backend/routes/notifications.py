"""Unified notifications.

GET materialises SLA nearing / breached events for the user's open cases
(deduplicated), so a citizen sees the whole journey in one dashboard.
"""

from flask import Blueprint, jsonify, request

from core import ensure_sla_notifications
from database import get_collection
from security import now_iso, public, require_officer, require_user

notifications_bp = Blueprint("notifications", __name__)


@notifications_bp.get("")
@require_user
def list_notifications(user, token):
    ensure_sla_notifications(user.get("email"))
    rows = get_collection("notifications").find({"userId": user.get("email")})
    rows.sort(key=lambda n: n.get("createdAt") or "", reverse=True)
    unseen = get_collection("notifications").count_documents({"userId": user.get("email"), "read": False})
    return jsonify({"count": len(rows), "unseen": unseen, "notifications": [public(n) for n in rows]})


@notifications_bp.get("/unseen")
@require_user
def unseen_count(user, token):
    ensure_sla_notifications(user.get("email"))
    return jsonify({"unseen": get_collection("notifications").count_documents(
        {"userId": user.get("email"), "read": False})})


@notifications_bp.post("")
@require_officer
def create_notification(user, officer):
    data = request.get_json(silent=True) or {}
    recipient = (data.get("userId") or "").strip()
    message = (data.get("message") or "").strip()
    kind = data.get("type") or "update"

    if not recipient or not message:
        return jsonify({"error": "userId and message are required"}), 400

    notification = {
        "userId": recipient,
        "type": kind,
        "message": message,
        "caseId": data.get("caseId") or None,
        "read": False,
        "createdAt": now_iso(),
    }
    result = get_collection("notifications").insert_one(notification)
    notification["id"] = str(result.inserted_id)
    return jsonify(public(notification)), 201


@notifications_bp.post("/read")
@require_user
def mark_read(user, token):
    data = request.get_json(silent=True) or {}
    notification_id = data.get("id")
    filt = {"userId": user.get("email")}
    if notification_id:
        filt["_id"] = notification_id
    get_collection("notifications").update_one(filt, {"$set": {"read": True}})
    unseen = get_collection("notifications").count_documents(
        {"userId": user.get("email"), "read": False}
    )
    return jsonify({"message": "Marked as read", "unseen": unseen})