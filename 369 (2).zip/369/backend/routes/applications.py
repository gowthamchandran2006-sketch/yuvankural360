"""Applications are now backed by unified cases (IK IDs).

A submitted application automatically creates a journey (case + SLA) via
core.create_journey, and an existing open journey for the same service is
returned instead of a duplicate.
"""

import re

from flask import Blueprint, jsonify, request

from core import create_journey, enrich
from database import get_collection
from security import now_iso, public, require_officer, require_user

applications_bp = Blueprint("applications", __name__)


@applications_bp.post("")
@require_user
def create_application(user, token):
    data = request.get_json(silent=True) or {}
    name = (data.get("applicantName") or user.get("name") or "").strip()
    mobile = str(data.get("applicantMobile") or user.get("mobile") or "").strip()
    service = (data.get("service") or "").strip()
    email = user.get("email")

    if not name or not service:
        return jsonify({"error": "Name and service are required"}), 400
    if not re.fullmatch(r"\d{10}", mobile):
        return jsonify({"error": "Mobile number must be 10 digits"}), 400

    case, app, error = create_journey(user, data, kind="application")
    if error:
        status = 409 if error.get("caseId") else 400
        return jsonify(error), status

    result = dict(app)
    result["caseId"] = case.get("caseId")
    result["sla"] = enrich(case)["sla"]
    result["caseStatus"] = case.get("status")
    result["id"] = app.get("id")
    return jsonify(public(result)), 201


@applications_bp.get("")
@require_user
def list_applications(user, token):
    rows = get_collection("applications").find({"userId": user.get("email")})
    result = []
    for app in rows:
        doc = public(app)
        case = get_collection("cases").find_one({"caseId": app.get("caseId")})
        if case:
            doc["caseId"] = case.get("caseId")
            doc["caseStatus"] = case.get("status")
            doc["sla"] = enrich(case)["sla"]
            doc["priority"] = enrich(case)["priority"]
        result.append(doc)
    return jsonify({"count": len(result), "applications": result})


@applications_bp.get("/<application_id>/status")
@require_user
def track_application(user, token, application_id):
    app = get_collection("applications").find_one({"_id": application_id}) \
        or get_collection("applications").find_one({"applicationId": application_id})
    if not app or (app.get("userId") != user.get("email") and user.get("role") == "citizen"):
        return jsonify({"error": "Application not found"}), 404
    case = get_collection("cases").find_one({"caseId": app.get("caseId")})
    body = {
        "applicationId": app.get("applicationId"),
        "caseId": app.get("caseId"),
        "service": app.get("service"),
        "status": case.get("status") if case else app.get("status"),
        "createdAt": app.get("createdAt"),
    }
    if case:
        body["history"] = case.get("history", [])
        body["sla"] = enrich(case)["sla"]
    return jsonify(body)


@applications_bp.patch("/<application_id>/status")
@require_officer
def update_application_status(user, officer, application_id):
    data = request.get_json(silent=True) or {}
    status = (data.get("status") or "").strip()
    allowed = {"Applied", "Under Review", "Approved", "Rejected", "Completed"}
    if status not in allowed:
        return jsonify({"error": f"Status must be one of: {sorted(allowed)}"}), 400

    app = get_collection("applications").find_one({"_id": application_id})
    if not app:
        return jsonify({"error": "Application not found"}), 404
    get_collection("applications").update_one(
        {"_id": application_id},
        {"$set": {"status": status, "updatedAt": now_iso(), "officer": user.get("email")}},
    )
    if app.get("caseId"):
        core_update = {"Applied": "Pending", "Under Review": "Processing",
                       "Approved": "Approved", "Rejected": "Rejected", "Completed": "Resolved"}[status]
        from core import add_history, audit
        add_history(app["caseId"], core_update, note=data.get("note"), by=user.get("email"), via="officer")
        audit(user.get("email"), user.get("role", "officer"), "application.status",
              case_id=app.get("caseId"), service=app.get("service"), detail=f"-> {status}")
    return jsonify({"message": "Status updated", "status": status})