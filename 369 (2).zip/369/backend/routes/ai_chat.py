"""Yuvakurazh AI assistant (rule-based NLU, English / Tanglish / Tamil).

The chat understands a citizen's natural-language need, routes it through the
service registry (service -> department -> office), guides on documents and
workflow, and can check the status of an existing case. It recommends and
explains — it never decides eligibility.
"""

from flask import Blueprint, jsonify, request

from core import resolve_service

ai_bp = Blueprint("ai", __name__)

TRACK_KEYWORDS = ["track", "status", "follow", "pogress", "naal aachu", "pending",
                  "enthu naalithu", "case id", "update aachaa", "enna naala", "how long"]

HELLO_KEYWORDS = ["hi", "hello", "vanakkam", "hey", "namaste", "annai"]


def _is_track(text):
    return any(kw in text for kw in TRACK_KEYWORDS)


def _is_hello(text):
    return any(kw in text for kw in HELLO_KEYWORDS)


@ai_bp.post("")
def chat():
    data = request.get_json(silent=True) or {}
    text = (data.get("message") or "").strip()
    user = (data.get("user") or {}).get("email") if isinstance(data.get("user"), dict) else None

    if not text:
        return jsonify({"error": "message is required"}), 400

    lowered = text.lower()

    if _is_hello(lowered):
        return jsonify({
            "intent": "greeting",
            "title": "Vanakkam! Yuvakurazh AI",
            "message": (
                "Tell me what you need in simple words — Tamil, English or Tanglish. "
                "For example: \"Enakku income certificate venum\", \"scholarship edhavadhu "
                "irukka?\", \"python free training irukka?\", or \"birth certificate "
                "venum\". I will guide you to the right government service and department."
            ),
            "next_steps": [],
            "link": "services.html",
            "voice_hint": True,
        })

    if _is_track(lowered):
        # Try to extract an IK case-id embedded in the message
        import re
        m = re.search(r"ik-?\d{4}-?\d{6}", lowered, flags=re.IGNORECASE)
        if m:
            from database import get_collection
            from core import enrich
            case = get_collection("cases").find_one({"caseId": m.group(0).replace("-", "IK-")}) \
                or get_collection("cases").find_one({"caseId": m.group(0).upper()})
            if case:
                sla = enrich(case).get("sla", {})
                if user and case.get("userId") != user and case.get("userId"):
                    from core import sla_state
                    status_line = f"'{case.get('status')}' at {case.get('office') or case.get('department')}."
                else:
                    status_line = f"'{case.get('status')}' at {case.get('office') or case.get('department')}."
                return jsonify({
                    "intent": "track",
                    "title": f"Case {case.get('caseId')}",
                    "message": (
                        f"Your {case.get('serviceName') or case.get('service')} journey is "
                        f"{status_line} SLA state: {sla.get('state')} "
                        f"({sla.get('progress')}% elapsed)."
                    ),
                    "next_steps": ["View full history", "Check SLA deadline", "Raise a linked grievance if delayed"],
                    "link": "track-case.html",
                    "caseId": case.get("caseId"),
                    "department": case.get("department"),
                    "office": case.get("office"),
                })
        return jsonify({
            "intent": "track",
            "title": "Track an application",
            "message": (
                "You can check your journey with your Yuvakurazh Case ID "
                "(IK-2026-XXXXXX). Enter it on the track page, or send it here like "
                "\"status of IK-2026-000123\"."
            ),
            "next_steps": ["Open track page", "Enter the Case ID", "View SLA deadline and history"],
            "link": "track-case.html",
        })

    route = resolve_service(text)
    if not route.get("matched"):
        return jsonify({
            "intent": "fallback",
            "title": "Let me understand better…",
            "message": route.get("message"),
            "next_steps": [],
            "link": "services.html",
        })

    docs = ", ".join(route["documents"]) if route.get("documents") else "as informed by the official workflow"
    steps = route.get("workflow") or ["Submit the application", "Department verification", "Decision"]

    message = (
        f"I identified **{route['name']}** for your need. "
        f"It is serviced by the **{route['department']}** ({route['office']}). "
        f"Typical processing time: {route['slaDays']} days. "
        f"Required documents: {docs}."
    )
    return jsonify({
        "intent": (route["service"] or "").lower().replace(" ", "_"),
        "title": route["name"],
        "message": message,
        "next_steps": [f"Department: {route['department']}", f"Office: {route['office']}",
                       f"Jurisdiction: {route.get('jurisdiction')}", *steps],
        "link": route.get("page") or "services.html",
        "department": route.get("department"),
        "departmentCode": route.get("departmentCode"),
        "office": route.get("office"),
        "officeCode": route.get("officeCode"),
        "documents": route.get("documents"),
        "workflow": route.get("workflow"),
        "slaDays": route.get("slaDays"),
        "contact": route.get("contact"),
        "matchedKeywords": route.get("matchedKeywords"),
    })


@ai_bp.post("/route")
def ai_route():
    """Same routing engine, JSON-strict shape (used by the frontend routing quiz)."""
    data = request.get_json(silent=True) or {}
    message = (data.get("message") or data.get("q") or "").strip()
    if not message:
        return jsonify({"error": "message is required"}), 400
    route = resolve_service(message)
    return jsonify(route), 200 if route.get("matched") else 404