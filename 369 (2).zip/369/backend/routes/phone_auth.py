"""Phone.email (OTP) sign-in verification.

The Phone.email button hands the browser a short lived
``user_json_url``. The browser must never be trusted, so this
route re-fetches that URL itself, checks it really is a
Phone.email host, and only then signs the citizen in.

Without that host check this endpoint would let anyone make the
server fetch an arbitrary internal address.
"""

import json
import urllib.error
import urllib.parse
import urllib.request

from flask import Blueprint, jsonify, request

from config import Config
from database import get_collection
from security import generate_token, now_iso, public

phone_bp = Blueprint("phone", __name__)

ALLOWED_HOST_SUFFIXES = (
    "phone.email",
    "www.phone.email",
    "firebasely.com",
    "www.firebasely.com",
    "api.phone.email",
)

FETCH_TIMEOUT = 8


def _host_allowed(url):
    """True only for an https Phone.email URL."""
    try:
        parts = urllib.parse.urlparse(url)
    except ValueError:
        return False

    if parts.scheme != "https":
        return False

    host = (parts.hostname or "").lower()

    return any(host == ok or host.endswith("." + ok) for ok in ALLOWED_HOST_SUFFIXES)


def _fetch_user(url):
    """Download the Phone.email profile document."""
    request_obj = urllib.request.Request(
        url,
        headers={"Accept": "application/json"},
    )

    with urllib.request.urlopen(request_obj, timeout=FETCH_TIMEOUT) as response:
        raw = response.read(64 * 1024)

    return json.loads(raw.decode("utf-8"))


def _first_str(payload, keys):
    """Pull the first non empty string out of a few possible keys."""
    for key in keys:
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _digits(value):
    """Digits only."""
    return "".join(char for char in str(value) if char.isdigit())


def _india_mobile(value):
    """Normalise to the 10 digit form used everywhere else.

    The OTP provider sends +91 98765 43210, so the raw digits come
    back as 919876543210. Keeping the country code here would stop
    the citizen ever matching an existing account.
    """
    digits = _digits(value)

    if not digits:
        return ""

    if len(digits) > 10:
        digits = digits[-10:]

    if len(digits) == 11 and digits.startswith("0"):
        digits = digits[1:]

    return digits if len(digits) == 10 else ""


@phone_bp.post("/api/verify-email")
def verify_email():
    """Confirm an address the citizen verified on the sign-up form.

    The browser sends the short lived ``user_json_url`` it was handed.
    It is re-fetcheted here exactly as verify_phone does, because an
    untrusted URL would otherwise let anyone make the server fetch an
    arbitrary internal address.

    No token is issued: the citizen is still filling in the form, so
    the verified address is only stashed for the account to pick up.
    """

    data = request.get_json(silent=True) or {}
    user_json_url = (data.get("user_json_url") or "").strip()

    if not user_json_url:
        return jsonify({"success": False, "message": "Missing verification details"}), 400

    if len(user_json_url) > 2000 or not _host_allowed(user_json_url):
        return jsonify({"success": False, "message": "Untrusted verification source"}), 400

    try:
        profile = _fetch_user(user_json_url)
    except (urllib.error.URLError, urllib.error.HTTPError, ValueError, OSError):
        return jsonify({"success": False, "message": "Could not reach the email provider"}), 502
    except json.JSONDecodeError:
        return jsonify({"success": False, "message": "Unreadable provider response"}), 502

    if not isinstance(profile, dict):
        return jsonify({"success": False, "message": "Unreadable provider response"}), 502

    email = _first_str(profile, ("email", "emailAddress", "email_address")).lower()

    if not email or "@" not in email:
        return jsonify(
            {"success": False, "message": "The provider did not return a valid email address"}
        ), 400

    # record the check so the admin console can see it
    get_collection("email_verifications").insert_one(
        {
            "email": email,
            "user_json_url": user_json_url,
            "verified_at": now_iso(),
        }
    )

    return jsonify({"success": True, "email": email})


@phone_bp.post("/api/verify-phone")
def verify_phone():
    data = request.get_json(silent=True) or {}
    user_json_url = (data.get("user_json_url") or "").strip()

    if not user_json_url:
        return jsonify({"success": False, "message": "Missing verification details"}), 400

    if len(user_json_url) > 2000 or not _host_allowed(user_json_url):
        return jsonify({"success": False, "message": "Untrusted verification source"}), 400

    try:
        profile = _fetch_user(user_json_url)
    except (urllib.error.URLError, urllib.error.HTTPError, ValueError, OSError):
        return jsonify({"success": False, "message": "Could not reach the OTP provider"}), 502
    except json.JSONDecodeError:
        return jsonify({"success": False, "message": "Unreadable provider response"}), 502

    if not isinstance(profile, dict):
        return jsonify({"success": False, "message": "Unreadable provider response"}), 502

    phone = _india_mobile(
        _first_str(profile, ("phone", "phoneNumber", "phone_number", "mobile"))
    )
    email = _first_str(profile, ("email", "emailAddress", "email_address")).lower()
    name = _first_str(profile, ("name", "displayName", "display_name")) or "Citizen"

    if not phone:
        return jsonify(
            {"success": False, "message": "The provider did not return a valid Indian mobile number"}
        ), 400

    users = get_collection("users")
    user = users.find_one({"mobile": phone})

    if user is None and email:
        user = users.find_one({"email": email})

    if user is None:
        # OTP is a first time sign in for this portal, so create the
        # citizen without a password. Password login simply will not
        # match until the citizen sets one.
        user = {
            "name": name,
            "mobile": phone,
            "role": "citizen",
            "auth_method": "phone_otp",
            "created_at": now_iso(),
        }
        if email:
            user["email"] = email

        # insert_one copies the document, so take the id it returns
        # rather than reading it back off the local dict.
        user["_id"] = users.insert_one(user).inserted_id
    else:
        patch = {"last_otp_login": now_iso()}
        if name and not user.get("name"):
            patch["name"] = name
        if email and not user.get("email"):
            patch["email"] = email
        users.update_one({"_id": user["_id"]}, {"$set": patch})
        user.update(patch)

    token = generate_token()
    get_collection("sessions").insert_one(
        {
            "token": token,
            "user_id": user.get("_id"),
            "email": user.get("email") or "",
            "mobile": phone,
            "auth_method": "phone_otp",
            "created_at": now_iso(),
        }
    )

    return jsonify({"success": True, "token": token, "user": public(user)})