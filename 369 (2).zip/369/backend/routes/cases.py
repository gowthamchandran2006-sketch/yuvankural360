"""Unified case management: one Case ID for the whole service journey.

Journeys are created here (and from applications) through core.create_journey,
which emits an IK-YYYY-NNNNNN Case ID, an SLA deadline and a status lifecycle.
"""

from flask import Blueprint, jsonify, request

from core import (
    CASE_STATUSES,
    STATUS_LABELS,
    add_history,
    audit,
    create_journey,
    enrich,
    resolve_service,
)
from database import get_collection
from security import now_iso, public, require_officer, require_user

cases_bp = Blueprint("cases", __name__)


def _is_owner_or_officer(user, case):
    return case.get("userId") == user.get("email") or user.get("role") != "citizen"


@cases_bp.post("")
@require_user
def create_case(user, token):
    payload = request.get_json(silent=True) or {}
    case, _app, error = create_journey(user, payload, kind="case")
    if error:
        status = 409 if error.get("caseId") else 400
        return jsonify(error), status
    return jsonify(enrich(case, with_user=True)), 201


@cases_bp.get("")
@require_user
def list_cases(user, token):
    rows = get_collection("cases").find({"userId": user.get("email")})
    enriched = [enrich(c) for c in rows]
    enriched.sort(key=lambda c: c.get("createdAt") or "", reverse=True)
    return jsonify({"count": len(enriched), "cases": [public(c) for c in enriched]})


@cases_bp.get("/track")
@require_user
def track_case(user, token):
    """Track a journey by its unified Case ID (IK-YYYY-NNNNNN)."""
    case_id = (request.args.get("caseId") or "").strip().upper()
    if not case_id:
        return jsonify({"error": "caseId query parameter is required"}), 400
    case = get_collection("cases").find_one({"caseId": case_id})
    if not case:
        return jsonify({"error": "Case not found. Check the Case ID and try again."}), 404
    if not _is_owner_or_officer(user, case):
        return jsonify({"error": "You can only track your own cases"}), 403
    app = get_collection("applications").find_one({"caseId": case_id}) or {}
    result = enrich(case, with_user=True)
    result["application"] = public(app) if app else None
    return jsonify(public(result))


@cases_bp.get("/<case_id>")
@require_user
def case_detail(user, token, case_id):
    case = get_collection("cases").find_one({"_id": case_id}) or get_collection("cases").find_one({"caseId": case_id})
    if not case:
        return jsonify({"error": "Case not found"}), 404
    if not _is_owner_or_officer(user, case):
        return jsonify({"error": "You can only view your own cases"}), 403
    return jsonify(public(enrich(case, with_user=True)))


@cases_bp.get("/<case_id>/history")
@require_user
def case_history(user, token, case_id):
    case = get_collection("cases").find_one({"caseId": case_id})
    if not case:
        case = get_collection("cases").find_one({"_id": case_id})
    if not case:
        return jsonify({"error": "Case not found"}), 404
    if not _is_owner_or_officer(user, case):
        return jsonify({"error": "Forbidden"}), 403
    return jsonify({"caseId": case.get("caseId"), "history": case.get("history", [])})


@cases_bp.patch("/<case_id>/status")
@require_officer
def update_case_status(user, officer, case_id):
    data = request.get_json(silent=True) or {}
    status = (data.get("status") or "").strip()
    note = (data.get("note") or "").strip()

    case = get_collection("cases").find_one({"caseId": case_id}) or get_collection("cases").find_one({"_id": case_id})
    if not case:
        return jsonify({"error": "Case not found"}), 404
    if status not in CASE_STATUSES:
        return jsonify({"error": f"Status must be one of: {CASE_STATUSES}"}), 400

    message = f"Your case {case_id} status changed to {status}."
    if status in STATUS_LABELS:
        message += " " + STATUS_LABELS[status]

    updated = add_history(case_id, status, note=note or STATUS_LABELS.get(status), by=officer.get("email"), via="officer")
    get_collection("notifications").insert_one(
        {"userId": case.get("userId"), "type": "case.status", "message": message,
         "caseId": case_id, "read": False, "createdAt": now_iso()}
    )
    audit(officer.get("email"), officer.get("role", "officer"), "case.status",
          case_id=case_id, service=case.get("service"), detail=f"status -> {status}: {note}")

    return jsonify({"message": "Status updated", "case": public(enrich(updated))})


@cases_bp.post("/<case_id>/handover")
@require_officer
def handover(user, officer, case_id):
    """Department-to-department handover — the same Case ID continues."""
    data = request.get_json(silent=True) or {}
    department = (data.get("department") or "").strip()
    office = (data.get("office") or "").strip()
    note = (data.get("note") or "").strip()

    case = get_collection("cases").find_one({"caseId": case_id}) or get_collection("cases").find_one({"_id": case_id})
    if not case:
        return jsonify({"error": "Case not found"}), 404

    department = department or case.get("department")
    office = office or case.get("office")
    cases = get_collection("cases")
    cases.update_one(
        {"caseId": case_id},
        {"$set": {
            "department": department,
            "office": office,
            "status": "Department Handover",
            "updatedAt": now_iso(),
        }},
    )
    updated = add_history(
        case_id,
        "Department Handover",
        note=note or f"Handed over to {department} / {office}",
        by=officer.get("email"),
        via="handover",
    )
    get_collection("notifications").insert_one(
        {"userId": case.get("userId"), "type": "case.handover",
         "message": f"Case {case_id} handed over to {department} ({office}). Same Case ID continues.",
         "caseId": case_id, "read": False, "createdAt": now_iso()}
    )
    audit(officer.get("email"), officer.get("role", "officer"), "case.handover",
          case_id=case_id, service=case.get("service"), detail=f"{department} / {office} : {note}")
    return jsonify({"message": "Case handed over", "case": public(enrich(updated))})


@cases_bp.post("/<case_id>/escalate")
@require_officer
def escalate(user, officer, case_id):
    data = request.get_json(silent=True) or {}
    note = (data.get("note") or "").strip()
    case = get_collection("cases").find_one({"caseId": case_id}) or get_collection("cases").find_one({"_id": case_id})
    if not case:
        return jsonify({"error": "Case not found"}), 404
    updated = add_history(case_id, "Escalated",
                          note=note or "Escalated per the defined SLA workflow",
                          by=officer.get("email"), via="escalation")
    get_collection("notifications").insert_one(
        {"userId": case.get("userId"), "type": "case.escalated",
         "message": f"Case {case_id} has been escalated. A higher authority will review it.",
         "caseId": case_id, "read": False, "createdAt": now_iso()}
    )
    audit(officer.get("email"), officer.get("role", "officer"), "case.escalate",
          case_id=case_id, service=case.get("service"), detail=note)
    return jsonify({"message": "Case escalated", "case": public(enrich(updated))})


@cases_bp.post("/route")
def route_query():
    """Public routing preview: plain-language -> service -> department/office."""
    data = request.get_json(silent=True) or {}
    query = (data.get("message") or data.get("q") or "").strip()
    if not query:
        return jsonify({"error": "message is required"}), 400
    result = resolve_service(query)
    if not result.get("matched"):
        return jsonify(result), 404
    return jsonify(result)