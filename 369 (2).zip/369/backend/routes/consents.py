"""Consent-based data reuse.

A citizen explicitly grants consent before any stored profile or document
information is reused for another application. Records are kept for the audit.
"""

from flask import Blueprint, jsonify, request

from core import audit
from database import get_collection
from security import now_iso, public, require_user

consents_bp = Blueprint("consents", __name__)

ALLOWED_KEYS = ("profile", "qualification", "documents", "identity", "contact")


@consents_bp.get("")
@require_user
def list_consents(user, token):
    rows = get_collection("consents").find({"userId": user.get("email")})
    return jsonify({"count": len(rows), "consents": [public(c) for c in rows]})


@consents_bp.post("")
@require_user
def grant_consent(user, token):
    data = request.get_json(silent=True) or {}
    data_key = (data.get("dataKey") or "").strip().lower()
    purpose = (data.get("purpose") or "").strip()
    allowed = bool(data.get("allowed", True))

    if data_key not in ALLOWED_KEYS:
        return jsonify({"error": f"dataKey must be one of {sorted(ALLOWED_KEYS)}"}), 400

    consent = {
        "userId": user.get("email"),
        "dataKey": data_key,
        "purpose": purpose or f"Reuse of {data_key} information for future applications",
        "allowed": allowed,
        "grantedAt": now_iso(),
    }
    existing = get_collection("consents").find_one({"userId": user.get("email"), "dataKey": data_key})
    if existing:
        get_collection("consents").update_one(
            {"_id": existing.get("_id") if existing.get("_id") else {"userId": user.get("email"), "dataKey": data_key}},
            {"$set": {"allowed": allowed, "purpose": consent["purpose"], "grantedAt": now_iso()}},
        )
        consent["id"] = str(existing.get("_id"))
    else:
        result = get_collection("consents").insert_one(consent)
        consent["id"] = str(result.inserted_id)
    audit(user.get("email"), user.get("role", "citizen"), "consent." + ("grant" if allowed else "revoke"),
          detail=f"dataKey={data_key} purpose={purpose}")
    return jsonify({"consent": consent}), 201


@consents_bp.post("/reuse")
@require_user
def reuse(user, token):
    """Preview what would be reused for a service, subject to granted consents."""
    data = request.get_json(silent=True) or {}
    data_key = (data.get("dataKey") or "profile").strip().lower()
    grants = get_collection("consents").find({"userId": user.get("email"), "dataKey": data_key, "allowed": True})
    if not grants:
        return jsonify({
            "reusable": False,
            "message": f"Consent for '{data_key}' is required before reusing your information.",
            "consentUrl": "/api/consents",
        }), 200
    profile = {}
    if data_key == "profile":
        profile = {
            "name": user.get("name"),
            "email": user.get("email"),
            "mobile": user.get("mobile"),
        }
    return jsonify({
        "reusable": True,
        "dataKey": data_key,
        "profile": profile,
        "message": "Information available for reuse with your consent.",
    })