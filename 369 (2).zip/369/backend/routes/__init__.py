from routes.admin import admin_bp
from routes.ai_chat import ai_bp
from routes.applications import applications_bp
from routes.audit import audit_bp
from routes.auth import auth_bp
from routes.cases import cases_bp
from routes.complaints import complaints_bp
from routes.consents import consents_bp
from routes.documents import documents_bp
from routes.notifications import notifications_bp
from routes.officers import officers_bp
from routes.phone_auth import phone_bp
from routes.posts import posts_bp
from routes.registry import registry_bp
from routes.services import services_bp
from routes.track import track_bp

__all__ = [
    "admin_bp",
    "ai_bp",
    "applications_bp",
    "audit_bp",
    "auth_bp",
    "cases_bp",
    "complaints_bp",
    "consents_bp",
    "documents_bp",
    "notifications_bp",
    "officers_bp",
    "phone_bp",
    "posts_bp",
    "registry_bp",
    "services_bp",
    "track_bp",
]