"""Yuvakurazh 360 backend entry point."""

from flask import Flask, jsonify
from flask_cors import CORS

from config import Config
from database import get_db_backend, init_db
from seed import seed


def create_app():
    import os
    app = Flask(__name__, static_folder=os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend")), static_url_path="")
    app.config["SECRET_KEY"] = Config.SECRET_KEY
    CORS(app)

    init_db()
    seed()

    from routes import (
        admin_bp,
        ai_bp,
        applications_bp,
        audit_bp,
        auth_bp,
        cases_bp,
        complaints_bp,
        consents_bp,
        documents_bp,
        notifications_bp,
        officers_bp,
        phone_bp,
        posts_bp,
        registry_bp,
        services_bp,
        track_bp,
    )

    app.register_blueprint(auth_bp, url_prefix="/api/auth")
    app.register_blueprint(admin_bp, url_prefix="/api/admin")
    app.register_blueprint(services_bp, url_prefix="/api/services")
    app.register_blueprint(registry_bp, url_prefix="/api/registry")
    app.register_blueprint(applications_bp, url_prefix="/api/applications")
    app.register_blueprint(complaints_bp, url_prefix="/api/complaints")
    app.register_blueprint(documents_bp, url_prefix="/api/documents")
    app.register_blueprint(cases_bp, url_prefix="/api/cases")
    app.register_blueprint(notifications_bp, url_prefix="/api/notifications")
    app.register_blueprint(officers_bp, url_prefix="/api/officers")
    app.register_blueprint(audit_bp, url_prefix="/api/audit")
    app.register_blueprint(consents_bp, url_prefix="/api/consents")
    app.register_blueprint(ai_bp, url_prefix="/api/chat")
    app.register_blueprint(phone_bp)
    app.register_blueprint(posts_bp, url_prefix="/api/posts")
    app.register_blueprint(track_bp, url_prefix="/api/track")

    @app.get("/")
    def root():
        return app.send_static_file("login.html")

    @app.get("/api/health")
    def health():
        return jsonify({"status": "ok", "database": get_db_backend()})

    @app.errorhandler(404)
    def not_found(_error):
        return jsonify({"error": "Not found"}), 404

    @app.errorhandler(500)
    def server_error(_error):
        return jsonify({"error": "Internal server error"}), 500

    return app


app = create_app()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=Config.PORT, debug=True)