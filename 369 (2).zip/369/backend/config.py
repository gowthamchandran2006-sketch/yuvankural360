import os

from dotenv import load_dotenv

load_dotenv()


class Config:
    MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
    DB_NAME = os.getenv("DB_NAME", "yuvakural_platform")
    DATA_DIR = os.getenv("DATA_DIR", os.path.join(os.path.dirname(os.path.abspath(__file__)), "data"))
    SECRET_KEY = os.getenv("SECRET_KEY", "yk-change-me")
    PORT = int(os.getenv("PORT", "5000"))
    OFFICER_EMAIL = os.getenv("OFFICER_EMAIL", "officer@yk.gov")
    OFFICER_PASSWORD = os.getenv("OFFICER_PASSWORD", "officer@123")

    # Administrator console (frontend/admin.html). One unique pair only:
    # change the values here or set ADMIN_EMAIL / ADMIN_PASSWORD in .env.
    ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "admin@yuva360.gov.in")
    ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "YkAdm!n360#Kq7Zp")

    TOKEN_BYTES = 32

    # Post photos. Kept out of the JSON store so posts.json stays small.
    UPLOAD_DIR = os.getenv(
        "UPLOAD_DIR", os.path.join(os.path.dirname(os.path.abspath(__file__)), "uploads")
    )
    MAX_CONTENT_LENGTH = int(os.getenv("MAX_CONTENT_LENGTH", str(8 * 1024 * 1024)))
    MAX_PHOTO_BYTES = int(os.getenv("MAX_PHOTO_BYTES", str(3 * 1024 * 1024)))