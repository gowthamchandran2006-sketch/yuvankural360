"""Yuvakurazh core engine.

Implements the SIH26129 interoperability concepts shared across routes:

* Unified Case ID   -> IK-YYYY-NNNNNN that tracks the whole service journey
* Status lifecycle  -> Submitted -> Processing -> Document Required ->
                       Department Handover -> Pending -> Approved/Rejected,
                       with Escalated / Resolved as exception states
* SLA monitoring    -> deadline computed from service.slaDays; stateless check
                       (ok / nearing / breached) evaluated at read time
* Smart routing     -> natural-language query (English / Tanglish / Tamil
                       keywords) -> service -> department -> office
* Duplicate detect  -> token-overlap similarity between complaint texts
* Audit trail       -> every authorised action recorded
"""

import re
from datetime import datetime, timedelta, timezone

from database import get_collection
from security import now_iso

CASE_PREFIX = "IK"

CASE_STATUSES = [
    "Submitted",
    "Processing",
    "Document Required",
    "Department Handover",
    "Pending",
    "Approved",
    "Rejected",
    "Escalated",
    "Resolved",
]

SLA_STATUSES = ["no_sla", "ok", "nearing", "breached"]

# --------------------------------------------------------------------------
# basics
# --------------------------------------------------------------------------


def utcnow():
    return datetime.now(timezone.utc)


def parse_dt(value):
    if not value:
        return None
    if isinstance(value, datetime):
        return value
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        try:
            return datetime.fromisoformat(str(value))
        except (TypeError, ValueError):
            return None


def make_case_id():
    year = utcnow().year
    seq = get_collection("cases").count_documents({}) + 1
    return f"{CASE_PREFIX}-{year}-{seq:06d}"


def audit(actor, role, action, detail="", case_id=None, service=None):
    """Record an authorised action on the audit trail."""
    get_collection("audit").insert_one(
        {
            "actor": actor,
            "role": role or "unknown",
            "action": action,
            "detail": detail,
            "caseId": case_id,
            "service": service,
            "at": now_iso(),
        }
    )


# --------------------------------------------------------------------------
# natural-language routing
# --------------------------------------------------------------------------

_NON_ALNUM = re.compile(r"[^a-z0-9\s]+")


def normalize(text):
    return _NON_ALNUM.sub(" ", (text or "").lower())


def _tokens(text):
    return set(normalize(text).split())


def _score_service(service, text, text_words, text_sorted):
    """Score a registry service against the user query."""
    score = 0
    matched = []
    for kw in (service.get("keywords") or []):
        kw = normalize(kw)
        if not kw:
            continue
        if kw in text:                        # multi-word / contiguous match
            score += 3
            matched.append(kw)
        elif kw in text_words:                # single keyword token
            score += 2
            matched.append(kw)
    # name / display-name token overlap
    for token in set(normalize(service.get("name")).split() + normalize(service.get("service")).split()):
        if token in text_words and len(token) > 2:
            score += 1
            matched.append(token)
    return score, list(dict.fromkeys(matched))[:5]


def resolve_service(query):
    """Route a plain-language query to a registry service.

    Returns dict(matched/...) or a fallback with suggestions. This is a
    deterministic rule engine — the final recommendation simply points to the
    official service definition; it never claims an eligibility decision.
    """
    text = normalize(query)
    text_words = _tokens(text)
    text_sorted = sorted(text_words)

    best = None
    best_score = 0
    for service in get_collection("services").find():
        score, matched = _score_service(service, text, text_words, text_sorted)
        if score > best_score:
            best_score = score
            best = {"service": service, "matched": matched, "score": score}

    if best is None or best_score < 3:
        return _fallback_route(query)

    svc = best["service"]
    dept = get_collection("departments").find_one({"code": svc.get("departmentCode")}) or {}
    office = get_collection("offices").find_one({"code": svc.get("officeCode")}) or {}
    return {
        "matched": True,
        "confidence": min(100, 40 + best_score * 12),
        "service": svc.get("service"),
        "name": svc.get("name"),
        "page": svc.get("page"),
        "icon": svc.get("icon"),
        "category": svc.get("category"),
        "department": dept.get("name") or svc.get("department"),
        "departmentCode": dept.get("code") or svc.get("departmentCode"),
        "office": office.get("name") or svc.get("office"),
        "officeCode": office.get("code") or svc.get("officeCode"),
        "jurisdiction": svc.get("jurisdiction") or office.get("jurisdiction"),
        "documents": svc.get("documents", []),
        "eligibility": svc.get("eligibility", []),
        "workflow": svc.get("workflow", []),
        "slaDays": svc.get("slaDays"),
        "contact": dept.get("contact") or svc.get("contact"),
        "matchedKeywords": best["matched"],
    }


def _fallback_route(query):
    return {
        "matched": False,
        "confidence": 0,
        "message": (
            "I could not confidently identify a government service from your "
            "request. Try: income certificate, scholarship, birth certificate, "
            "marriage registration, voter ID, job, skill training, pension, "
            "business loan, police NOC, or report a service issue."
        ),
        "service": None,
        "department": None,
        "office": None,
        "documents": [],
        "eligibility": [],
        "workflow": [],
        "slaDays": None,
    }


# --------------------------------------------------------------------------
# SLA + case enrichment
# --------------------------------------------------------------------------


def sla_state(case):
    """Evaluate SLA for a case from its deadline (computed from slaDays)."""
    if not case:
        return {"slaDays": None, "deadline": None, "state": "no_sla", "progress": 0, "remaining": None}
    sla_days = case.get("slaDays")
    if not sla_days:
        return {"slaDays": None, "deadline": None, "state": "no_sla", "progress": 0, "remaining": None}

    created = parse_dt(case.get("createdAt")) or utcnow()
    deadline = parse_dt(case.get("deadline")) or (created + timedelta(days=int(sla_days)))
    now = utcnow()

    total_seconds = max(86400, int(sla_days) * 86400)
    elapsed = max(0.0, (now - created).total_seconds())
    remaining = (deadline - now).total_seconds()
    progress = min(100.0, round(elapsed / total_seconds * 100, 1))

    if remaining <= 0:
        state = "breached"
    elif progress >= 80 or remaining <= 2 * 86400:
        state = "nearing"
    else:
        state = "ok"

    return {
        "slaDays": int(sla_days),
        "deadline": deadline.isoformat(),
        "state": state,
        "progress": progress,
        "remaining": round(remaining / 86400, 1),
    }


def priority(case):
    state = sla_state(case)["state"]
    status = (case.get("status") or "").lower()
    if state == "breached" or case.get("escalated"):
        return "High"
    if state == "nearing" or status in ("document required", "department handover"):
        return "Medium"
    return "Low"


def enrich(case, with_user=False):
    """Attach SLA summary, priority and service metadata for API responses."""
    if not case:
        return None
    doc = dict(case)
    doc["sla"] = sla_state(case)
    doc["priority"] = priority(case)
    doc["currentOffice"] = case.get("office") or case.get("currentOffice")
    proc = _tokens(case.get("service") or "")
    proc.add(case.get("serviceCode") or "")
    # attach department/office metadata from the case's own snapshot when available
    return doc


def add_history(case_id, status, note=None, by=None, via=None):
    """Append a lifecycle event. Persists both to the stored doc and in-memory copy."""
    cases = get_collection("cases")
    case = cases.find_one({"caseId": case_id})
    if not case:
        return None
    history = list(case.get("history", []))
    history.append(
        {
            "status": status,
            "note": note,
            "by": by,
            "via": via,
            "at": now_iso(),
        }
    )
    update = {
        "status": status,
        "history": history,
        "updatedAt": now_iso(),
    }
    if via == "escaltion":
        update["escalated"] = True
        update["escalatedAt"] = now_iso()
    cases.update_one({"caseId": case_id}, {"$set": update})
    return cases.find_one({"caseId": case_id})


# --------------------------------------------------------------------------
# journey creation (application + case)
# --------------------------------------------------------------------------

STATUS_LABELS = {
    "Submitted": "Application Submitted — awaiting department intake.",
    "Processing": "In processing with the concerned department.",
    "Document Required": "Additional documents requested by the department.",
    "Department Handover": "Case handed over to the next department/office.",
    "Pending": "Pending decision with the concerned authority.",
    "Approved": "Approved by the authorised department.",
    "Rejected": "Not approved. Reasons are available with the department.",
    "Escalated": "Escalated per the defined SLA workflow.",
    "Resolved": "Service journey completed.",
}


def create_journey(user, payload, kind="application"):
    """Create a unified case (+ application mirror) for a citizen request.

    Returns (case, application-or-None, error-or-None).
    """
    service_name = (payload.get("service") or "").strip()
    query_text = (payload.get("message") or payload.get("what") or "").strip()
    route = resolve_service(query_text or service_name) if not service_name else None

    if not service_name and route and route.get("matched"):
        service_name = route["name"] or route["service"]
        route = None

    services = get_collection("services")
    provider = None
    for candidate in services.find():
        if candidate.get("name") == service_name or candidate.get("service") == service_name:
            provider = candidate
            break
    if provider is None and route and route.get("matched"):
        for candidate in services.find():
            if candidate.get("service") == route.get("service") or candidate.get("name") == route.get("name"):
                provider = candidate
                break

    if provider is None:
        if route:
            return None, None, {"error": route.get("message", "Service not recognised.")}
        return None, None, {"error": "A recognised government service is required."}

    email = user.get("email")

    # Existing-application detection: one open journey per service per citizen.
    open_journeys = get_collection("cases").find(
        {"userId": email, "serviceCode": provider.get("service")}
    )
    for existing in open_journeys:
        if existing.get("status") not in ("Approved", "Rejected", "Resolved"):
            return existing, None, {
                "error": "You already have an open journey for this service.",
                "caseId": existing.get("caseId"),
            }

    case_id = make_case_id()
    sla_days = provider.get("slaDays")
    created = now_iso()
    deadline = None
    if sla_days:
        deadline = (utcnow() + timedelta(days=int(sla_days))).isoformat()

    case = {
        "caseId": case_id,
        "userId": email,
        "kind": kind,
        "service": provider.get("service"),
        "serviceCode": provider.get("service"),
        "serviceName": provider.get("name"),
        "department": provider.get("department"),
        "departmentCode": provider.get("departmentCode"),
        "office": provider.get("office"),
        "officeCode": provider.get("officeCode"),
        "jurisdiction": provider.get("jurisdiction"),
        "page": provider.get("page"),
        "icon": provider.get("icon") or "fa-file-lines",
        "documents": provider.get("documents", []),
        "workflow": provider.get("workflow", []),
        "slaDays": sla_days,
        "deadline": deadline,
        "status": "Submitted",
        "escalated": False,
        "currentOffice": payload.get("office") or provider.get("office"),
        "details": payload.get("details") or {},
        "applicantName": payload.get("applicantName") or user.get("name"),
        "applicantEmail": email,
        "applicantMobile": payload.get("applicantMobile") or user.get("mobile"),
        "history": [
            {
                "status": "Submitted",
                "note": STATUS_LABELS["Submitted"],
                "by": email,
                "via": "system",
                "at": created,
            }
        ],
        "createdAt": created,
        "updatedAt": created,
    }
    result = get_collection("cases").insert_one(case)
    case["id"] = str(result.inserted_id)

    # application mirror (kept for backwards compatibility with existing views)
    app = {
        "userId": email,
        "applicationId": f"YK-{created[:4]}-{get_collection('applications').count_documents({}) + 1:06d}",
        "caseId": case_id,
        "scholarship": provider.get("name"),
        "service": provider.get("service"),
        "serviceName": provider.get("name"),
        "department": provider.get("department"),
        "icon": provider.get("icon") or "fa-file-lines",
        "status": "Applied",
        "category": payload.get("category") or "",
        "qualification": payload.get("qualification") or "",
        "details": payload.get("details") or {},
        "applicantName": case["applicantName"],
        "applicantEmail": email,
        "applicantMobile": case["applicantMobile"],
        "createdAt": created,
        "updatedAt": created,
    }
    app_result = get_collection("applications").insert_one(app)
    app["id"] = str(app_result.inserted_id)

    audit(email, user.get("role", "citizen"), "case.create", case_id=case_id,
          service=provider.get("service"), detail=provider.get("name"))

    _notify(email, "case.submitted", f"Your journey is started. Case ID {case_id} ({provider.get('name')}).", case_id)
    return case, app, None


def _notify(user_id, kind, message, case_id=None):
    get_collection("notifications").insert_one(
        {
            "userId": user_id,
            "type": kind,
            "message": message,
            "caseId": case_id,
            "read": False,
            "createdAt": now_iso(),
        }
    )


def ensure_sla_notifications(user_id):
    """Materialise SLA nearing / breached notifications for the user's open cases."""
    created = []
    for case in get_collection("cases").find({"userId": user_id}):
        if case.get("status") in ("Approved", "Rejected", "Resolved"):
            continue
        sla = sla_state(case)
        state = sla["state"]
        if state in ("no_sla", "ok"):
            continue
        kind = "sla.breached" if state == "breached" else "sla.nearing"
        exists = get_collection("notifications").find_one(
            {"userId": user_id, "caseId": case.get("caseId"), "type": kind}
        )
        if not exists:
            if state == "breached":
                message = f"SLA breached for case {case['caseId']}. It has been escalated per the defined workflow."
                _notify(user_id, kind, message, case.get("caseId"))
                add_history(case["caseId"], "Escalated", note="SLA exceeded — auto escalation", by="system", via="escalation")
            else:
                message = f"SLA deadline is approaching for case {case['caseId']} ({sla['remaining']} days left)."
                _notify(user_id, kind, message, case.get("caseId"))
            created.append(kind)
    return created


# --------------------------------------------------------------------------
# duplicate detection
# --------------------------------------------------------------------------


def similar(a, b):
    """Token-overlap similarity in [0, 1]."""
    tokens_a = _tokens(a)
    tokens_b = _tokens(b)
    if not tokens_a or not tokens_b:
        return 0.0
    union = tokens_a | tokens_b
    intersect = tokens_a & tokens_b
    return len(intersect) / len(union)


def detect_duplicates(user_id, message, case_id=None):
    """Find the most similar existing complaint for the user, if any."""
    best = None
    best_score = 0.0
    for existing in get_collection("complaints").find({"userId": user_id}):
        if case_id and existing.get("caseId") == case_id:
            continue
        score = similar(message, f"{existing.get('subject', '')} {existing.get('message', '')}")
        if score > best_score:
            best_score = score
            best = existing
    if best and best_score >= 0.55:
        return {"similarTo": best.get("complaintId"), "score": round(best_score, 2), "status": best.get("status")}
    return None