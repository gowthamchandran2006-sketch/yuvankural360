"""Yuvakurazh seeding: departments, offices, enriched service registry,
SLA defaults and officer accounts."""

from config import Config
from database import get_collection
from security import hash_password, now_iso

# --------------------------------------------------------------------------
# departments
# --------------------------------------------------------------------------

DEPARTMENTS = [
    {"code": "REVENUE", "name": "Revenue Department", "contact": "Taluk / Tahsildar Office, district revenue administration"},
    {"code": "EDU", "name": "School & Higher Education Department", "contact": "District Education Office"},
    {"code": "LOCAL", "name": "Rural & Urban Local Bodies", "contact": "Corporation / Municipality / Town & Village Panchayat"},
    {"code": "REG", "name": "Registration Department", "contact": "Sub-Registrar Office, jurisdiction of marriage place"},
    {"code": "ELE", "name": "Election Department", "contact": "Concerned District Election Office"},
    {"code": "LABOUR", "name": "Labour & Employment Department", "contact": "District Employment Exchange"},
    {"code": "SKILL", "name": "Skill Development Department", "contact": "District Skill Development Office"},
    {"code": "HEALTH", "name": "Health & Family Welfare Department", "contact": "District Health Office / Chennai region health authorities"},
    {"code": "SOCIAL", "name": "Social Welfare Department", "contact": "District Social Welfare Office"},
    {"code": "COMMERCE", "name": "Industries & Commerce Department", "contact": "District Industries Centre"},
    {"code": "POLICE", "name": "Police Department", "contact": "CSP / Cybercrime cell, concerned police district"},
    {"code": "ADMIN", "name": "General Administration (Grievance Redressal)", "contact": "District Collector Office / Community grievance cell"},
]

OFFICES = [
    {"code": "TALUK", "name": "Taluk / Tahsildar Office", "departmentCode": "REVENUE", "jurisdiction": "Based on applicant's residential taluk"},
    {"code": "DEO", "name": "District Education Office", "departmentCode": "EDU", "jurisdiction": "Based on applicant's institution district"},
    {"code": "LOCALBODY", "name": "Corporation / Municipality / Panchayat", "departmentCode": "LOCAL", "jurisdiction": "Based on place of birth / residence"},
    {"code": "SR", "name": "Sub-Registrar Office", "departmentCode": "REG", "jurisdiction": "Based on place of marriage"},
    {"code": "ELEDIST", "name": "District Election Office", "departmentCode": "ELE", "jurisdiction": "Based on registered residence"},
    {"code": "EEX", "name": "District Employment Exchange", "departmentCode": "LABOUR", "jurisdiction": "Based on applicant's residential district"},
    {"code": "SKILLDIST", "name": "District Skill Development Office", "departmentCode": "SKILL", "jurisdiction": "Based on applicant's residential district"},
    {"code": "HEALTHDIST", "name": "District Health Office", "departmentCode": "HEALTH", "jurisdiction": "Based on applicant's residential district"},
    {"code": "SWO", "name": "District Social Welfare Office", "departmentCode": "SOCIAL", "jurisdiction": "Based on applicant's residential district"},
    {"code": "DIC", "name": "District Industries Centre", "departmentCode": "COMMERCE", "jurisdiction": "Based on business premises district"},
    {"code": "POLICEDIST", "name": "Concerned Police District / Cyber Crime Cell", "departmentCode": "POLICE", "jurisdiction": "Based on incident / residence"},
    {"code": "COL", "name": "District Collector Office (Grievance Cell)", "departmentCode": "ADMIN", "jurisdiction": "State-wide"},
]

# --------------------------------------------------------------------------
# services
# --------------------------------------------------------------------------

BASE_SERVICES = [
    {
        "service": "Education",
        "name": "Education Scholarship",
        "department": "School & Higher Education Department",
        "departmentCode": "EDU",
        "office": "District Education Office",
        "officeCode": "DEO",
        "jurisdiction": "Based on applicant's institution district",
        "category": "Education",
        "icon": "fa-graduation-cap",
        "description": "Financial support for students pursuing school and college education.",
        "eligibility": ["Indian resident", "Family income below slab", "Student pursuing education"],
        "documents": ["Aadhaar", "Income certificate", "Marksheet", "Bank account"],
        "workflow": ["Submit application with documents", "Education department verification", "Income/eligibility check", "Sanction approval", "Disbursement"],
        "slaDays": 30,
        "keywords": ["scholarship", "education", "student", "study", "fee", "college", "stipend", "padippu", "padippu maanavar", "fee concession", "merit"],
        "page": "government-scholarship.html",
        "eligibility_score_bias": 2,
    },
    {
        "service": "Certificate",
        "name": "Income Certificate",
        "department": "Revenue Department",
        "departmentCode": "REVENUE",
        "office": "Taluk / Tahsildar Office",
        "officeCode": "TALUK",
        "jurisdiction": "Based on applicant's residential taluk",
        "category": "Certificate",
        "icon": "fa-file-circle-check",
        "description": "Certification of family income used for scheme eligibility.",
        "eligibility": ["Resident of the state", "Valid supporting proof"],
        "documents": ["Aadhaar", "Address proof", "Ration card", "Latest income proof"],
        "workflow": ["Submit application", "Taluk office verification", "Revenue inspector field check", "Tahsildar approval", "Issue certificate"],
        "slaDays": 21,
        "keywords": ["income certificate", "income cert", "revenue certificate", "varuvai", "varuvai certificate", "income", "certificate", "caste certificate", "residence certificate"],
        "page": "certificates.html",
    },
    {
        "service": "Birth Certificate",
        "name": "Birth Certificate",
        "department": "Rural & Urban Local Bodies",
        "departmentCode": "LOCAL",
        "office": "Corporation / Municipality / Panchayat",
        "officeCode": "LOCALBODY",
        "jurisdiction": "Based on place of birth / residence",
        "category": "Certificate",
        "icon": "fa-baby",
        "description": "Official certificate of birth issued by the local body having jurisdiction over the place of birth.",
        "eligibility": ["Birth registered with the concerned local body", "Applicant / guardian applies"],
        "documents": ["Hospital birth record", "Hospital discharge summary", "Parents Aadhaar", "Address proof of place of birth"],
        "workflow": ["Locate registrable local body by place of birth", "Submit parent details", "Verification with hospital/institutional record", "Issue birth certificate"],
        "slaDays": 15,
        "keywords": ["birth certificate", "birth", "birth cert", "piravi", "piravi certificate", "janana", "new born", "baby certificate"],
        "page": "certificates.html",
    },
    {
        "service": "Marriage Registration",
        "name": "Marriage Registration",
        "department": "Registration Department",
        "departmentCode": "REG",
        "office": "Sub-Registrar Office",
        "officeCode": "SR",
        "jurisdiction": "Based on place of marriage",
        "category": "Certificate",
        "icon": "fa-ring",
        "description": "Compulsory registration of marriage under the Registration Act.",
        "eligibility": ["Marriage performed / solemnised in the state", "Both parties eligible to consent"],
        "documents": ["Marriage invitation", "Photographs", "Age proof of both parties", "Witness details (2)"],
        "workflow": ["Submit marriage particulars", "Sub-Registrar office scrutiny", "Verification of documents and witnesses", "Register certificate"],
        "slaDays": 14,
        "keywords": ["marriage", "marriage registration", "kalyanam", "kalyanam registration", "thirumana", "thirumana pativu", "wedding"],
        "page": "certificates.html",
    },
    {
        "service": "Voter Service",
        "name": "Voter ID Service",
        "department": "Election Department",
        "departmentCode": "ELE",
        "office": "District Election Office",
        "officeCode": "ELEDIST",
        "jurisdiction": "Based on registered residence",
        "category": "Election",
        "icon": "fa-check-double",
        "description": "New voter registration and corrections to existing voter records.",
        "eligibility": ["18 years of age or above", "Ordinary resident of the constituency"],
        "documents": ["Proof of residence", "Age proof", "Recent photograph"],
        "workflow": ["Fill Form 6 / amendment form", "Election office enrolment check", "Verification by BLO", "Electoral roll update"],
        "slaDays": 35,
        "keywords": ["voter", "voter id", "voter card", "election", "vote", "epic", "thadar", "votu", "voter registration"],
        "page": "services.html",
    },
    {
        "service": "Employment",
        "name": "Employment Registration",
        "department": "Labour & Employment Department",
        "departmentCode": "LABOUR",
        "office": "District Employment Exchange",
        "officeCode": "EEX",
        "jurisdiction": "Based on applicant's residential district",
        "category": "Employment",
        "icon": "fa-briefcase",
        "description": "Registration for job seekers to receive employment assistance.",
        "eligibility": ["18 years or older", "Educational qualification declared"],
        "documents": ["Aadhaar", "Qualification certificate", "Photo"],
        "workflow": ["Register job-seeker profile", "Qualification verification", "Placement assistance matching"],
        "slaDays": 20,
        "keywords": ["job", "employment", "work", "career", "employ", "interview", "velai", "vetti", "udhaniyogam", "job seeker", "job matching"],
        "page": "employment.html",
    },
    {
        "service": "Skill Development",
        "name": "Skill Development Training",
        "department": "Skill Development Department",
        "departmentCode": "SKILL",
        "office": "District Skill Development Office",
        "officeCode": "SKILLDIST",
        "jurisdiction": "Based on applicant's residential district",
        "category": "Skill",
        "icon": "fa-toolbox",
        "description": "Short-term vocational training to improve employability.",
        "eligibility": ["Youth in eligible age band", "Willingness to complete training"],
        "documents": ["Aadhaar", "Education details"],
        "workflow": ["Choose the training course", "Enrolment", "Classroom/practical training", "Assessment", "Certificate on completion"],
        "slaDays": 45,
        "keywords": ["skill", "training", "course", "learn", "vocational", "python training", "computer course", "payirchi", "coputer payirchi"],
        "page": "skill-development.html",
    },
    {
        "service": "Health",
        "name": "Health Benefits",
        "department": "Health & Family Welfare Department",
        "departmentCode": "HEALTH",
        "office": "District Health Office",
        "officeCode": "HEALTHDIST",
        "jurisdiction": "Based on applicant's residential district",
        "category": "Health",
        "icon": "fa-heart-pulse",
        "description": "Free checkups, hospital assistance and medicine support schemes.",
        "eligibility": ["Resident of the state", "Applicable to family/individual schemes"],
        "documents": ["Aadhaar", "Medical records if needed"],
        "workflow": ["Choose the health scheme", "Eligibility pre-check", "Application with medical records"],
        "slaDays": 25,
        "keywords": ["health", "hospital", "medicine", "ambulance", "checkup", "doctor", "treatment", "aaspathiri"],
        "page": "health.html",
    },
    {
        "service": "Welfare",
        "name": "Welfare Scheme",
        "department": "Social Welfare Department",
        "departmentCode": "SOCIAL",
        "office": "District Social Welfare Office",
        "officeCode": "SWO",
        "jurisdiction": "Based on applicant's residential district",
        "category": "Welfare",
        "icon": "fa-hand-holding-heart",
        "description": "Pensions and family welfare support for eligible families.",
        "eligibility": ["Age/Below poverty criteria as per scheme"],
        "documents": ["Aadhaar", "Bank account", "Income proof"],
        "workflow": ["Choose the welfare scheme", "Age/income eligibility check", "Verification and sanction"],
        "slaDays": 30,
        "keywords": ["pension", "welfare", "old age", "widow", "widow pension", "disability", "benefit", "pension scheme"],
        "page": "welfare.html",
    },
    {
        "service": "Business",
        "name": "Business Loan",
        "department": "Industries & Commerce Department",
        "departmentCode": "COMMERCE",
        "office": "District Industries Centre",
        "officeCode": "DIC",
        "jurisdiction": "Based on business premises district",
        "category": "Business",
        "icon": "fa-store",
        "description": "Loans and startup support for entrepreneurs and small businesses.",
        "eligibility": ["Business plan available", "18 years or older"],
        "documents": ["Aadhaar", "PAN", "Business plan", "Bank statement"],
        "workflow": ["Submit business plan", "Scheme matching", "Bank credit appraisal", "Disbursement"],
        "slaDays": 40,
        "keywords": ["business", "business loan", "loan", "startup", "msme", "shop", "entrepreneur", "thozhil"],
        "page": "business.html",
    },
    {
        "service": "Grievance",
        "name": "Grievance Support",
        "department": "General Administration (Grievance Redressal)",
        "departmentCode": "ADMIN",
        "office": "District Collector Office (Grievance Cell)",
        "officeCode": "COL",
        "jurisdiction": "State-wide",
        "category": "Grievance",
        "icon": "fa-message",
        "description": "Register complaints or issues against government services.",
        "eligibility": ["Any citizen"],
        "documents": ["Issue details", "Optional evidence"],
        "workflow": ["Register the grievance", "Link to existing case if applicable", "Grievance cell review", "Action / resolution"],
        "slaDays": 15,
        "keywords": ["grievance", "complaint", "issue", "problem", "report", "puriya", "pirivu", "complaint about"],
        "page": "report-issue.html",
    },
    {
        "service": "Police Support",
        "name": "Police Support",
        "department": "Police Department",
        "departmentCode": "POLICE",
        "office": "Concerned Police District / Cyber Crime Cell",
        "officeCode": "POLICEDIST",
        "jurisdiction": "Based on incident / residence",
        "category": "Safety",
        "icon": "fa-shield-halved",
        "description": "Assistance for visits, complaints, NOC and character certificates.",
        "eligibility": ["Any citizen"],
        "documents": ["Aadhaar", "Address proof"],
        "workflow": ["Choose the police service", "Submit details", "Station verification", "NOC/certificate issue"],
        "slaDays": 10,
        "keywords": ["police", "safety", "noc", "character certificate", "station", "cyber", "cybercrime", "kaval", "police complaint"],
        "page": "police-support.html",
    },
    {
        "service": "Women & Child",
        "name": "Women & Child Support",
        "department": "Social Welfare Department",
        "departmentCode": "SOCIAL",
        "office": "District Social Welfare Office",
        "officeCode": "SWO",
        "jurisdiction": "Based on applicant's residential district",
        "category": "Women & Child",
        "icon": "fa-people-roof",
        "description": "Maternity, girl child and family support schemes.",
        "eligibility": ["Women/Child as per scheme criteria"],
        "documents": ["Aadhaar", "Bank account"],
        "workflow": ["Choose the scheme", "Eligibility check", "Verification and sanction"],
        "slaDays": 25,
        "keywords": ["women", "child", "maternity", "girl", "maternity benefit", "anganwadi", "girl child"],
        "page": "women-child.html",
    },
]


def seed():
    for table, rows in (("departments", DEPARTMENTS), ("offices", OFFICES)):
        coll = get_collection(table)
        if coll.count_documents({}) == 0:
            for item in rows:
                coll.insert_one(dict(item))

    services = get_collection("services")
    if services.count_documents({}) == 0:
        for item in BASE_SERVICES:
            services.insert_one(dict(item))

    officers = get_collection("officers")
    if officers.count_documents({"email": Config.OFFICER_EMAIL}) == 0:
        officers.insert_one(
            {
                "email": Config.OFFICER_EMAIL,
                "name": "Platform Administrator",
                "role": "system_admin",
                "department": "Administration",
                "departmentCode": "ADMIN",
                "password": hash_password(Config.OFFICER_PASSWORD),
                "created_at": now_iso(),
            }
        )
    if officers.count_documents({"email": "officer.dept@yk.gov"}) == 0:
        officers.insert_one(
            {
                "email": "officer.dept@yk.gov",
                "name": "Revenue Department Officer",
                "role": "officer",
                "department": "Revenue Department",
                "departmentCode": "REVENUE",
                "password": hash_password("officer@123"),
                "created_at": now_iso(),
            }
        )

    # Administrator console: the single unique pair from config.py.
    admins = get_collection("admins")
    if admins.count_documents({"email": Config.ADMIN_EMAIL}) == 0:
        admins.insert_one(
            {
                "email": Config.ADMIN_EMAIL,
                "name": "Platform Administrator",
                "role": "administrator",
                "department": "Administration",
                "departmentCode": "ADMIN",
                "password": hash_password(Config.ADMIN_PASSWORD),
                "created_at": now_iso(),
            }
        )