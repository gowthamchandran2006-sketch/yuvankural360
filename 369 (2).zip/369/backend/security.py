"""Shared helpers: hashing, tokens, decorators, serializers."""

import hmac
import secrets
import hashlib
from datetime import datetime, timezone
from functools import wraps

from flask import jsonify, request

from config import Config
from database import get_collection

PBKDF2_ITERATIONS = 100_000


def hash_password(password, salt=None):
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt.encode("utf-8"), PBKDF2_ITERATIONS
    ).hex()
    return f"pbkdf2_sha256${salt}${digest}"


def verify_password(password, stored):
    if not stored:
        return False
    try:
        _algo, salt, _digest = stored.split("$")
        candidate = hash_password(password, salt)
        return hmac.compare_digest(candidate, stored)
    except (ValueError, AttributeError):
        return False


def generate_token():
    return secrets.token_urlsafe(Config.TOKEN_BYTES)


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def public(doc):
    """Serialize a stored document (handle _id, datetime) for JSON."""
    _private = {"password", "token", "otp", "otp_hash"}
    result = {}
    for key, value in (doc or {}).items():
        if key == "_id":
            result["id"] = str(value)
            continue
        if key in _private:
            continue
        if hasattr(value, "isoformat"):
            value = value.isoformat()
        result[key] = value
    return result


def _bearer_user():
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return None
    token = auth.split(" ", 1)[1].strip()
    if not token:
        return None
    session = get_collection("sessions").find_one({"token": token})
    if not session:
        return None

    users = get_collection("users")

    # Newer sessions carry the user id, which is the only stable key:
    # an OTP citizen may have no email address at all.
    user = None
    if session.get("user_id"):
        user = users.find_one({"_id": session["user_id"]})
    if user is None:
        user = users.find_one({"email": session.get("email")})

    # a token can outlive its account, and an officer or admin session has
    # no citizen row at all - both mean "not signed in as a citizen"
    if user is None:
        return None

    return user, token


def require_user(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        result = _bearer_user()
        if not result:
            return jsonify({"error": "Authentication required"}), 401
        user, token = result
        return fn(user=user, token=token, *args, **kwargs)

    return wrapper


def require_officer(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        token = None
        if auth.startswith("Bearer "):
            token = auth.split(" ", 1)[1].strip()
        if not token:
            return jsonify({"error": "Authentication required"}), 401
        session = get_collection("sessions").find_one({"token": token})
        if not session:
            return jsonify({"error": "Authentication required"}), 401
        officer = get_collection("officers").find_one(
            {"email": session.get("email")}
        )
        if not officer:
            return jsonify({"error": "Officer access required"}), 403
        return fn(user=officer, officer=officer, *args, **kwargs)

    return wrapper


def require_admin(fn):
    """Guard for the administrator console. A citizen or officer token is
    not enough: the session must carry scope "admin" and the email must
    still exist in the admins collection."""

    @wraps(fn)
    def wrapper(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        token = None
        if auth.startswith("Bearer "):
            token = auth.split(" ", 1)[1].strip()
        if not token:
            return jsonify({"error": "Authentication required"}), 401
        session = get_collection("sessions").find_one({"token": token})
        if not session:
            return jsonify({"error": "Authentication required"}), 401
        if session.get("scope") != "admin":
            return jsonify({"error": "Administrator access required"}), 403
        admin = get_collection("admins").find_one({"email": session.get("email")})
        if not admin:
            return jsonify({"error": "Administrator access required"}), 403
        return fn(user=admin, admin=admin, *args, **kwargs)

    return wrapper