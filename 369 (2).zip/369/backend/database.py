"""Database layer for Yuvakurazh 360.

Tries MongoDB first; falls back to a file-backed store when MongoDB is
not reachable so the API can still be exercised locally. The fallback keeps
accounts, sessions and cases on disk, so a restart never logs users out.
"""

import json
import os
import threading
import time
from types import SimpleNamespace

from pymongo import MongoClient

from config import Config

_state = {"mongo": None, "mode": "memory", "memory": {}}


class MemoryCollection:
    """Minimal collection-like wrapper that mirrors the subset of the
    PyMongo API used by the routes. Documents are cached in memory and
    flushed to a JSON file so data survives a restart."""

    def __init__(self, name, directory):
        self._file = os.path.join(directory, name + ".json")
        self._lock = threading.RLock()
        self._docs = []
        self._seq = 0
        self._load()

    def _load(self):
        try:
            # utf-8-sig so a file written by a Windows tool that adds a BOM
            # still parses instead of looking like a broken, empty store
            with open(self._file, "r", encoding="utf-8-sig") as handle:
                docs = json.load(handle)
        except FileNotFoundError:
            return
        except (OSError, ValueError) as exc:
            self._quarantine(exc)
            return
        if not isinstance(docs, list):
            return
        self._docs = [d for d in docs if isinstance(d, dict)]
        for doc in self._docs:
            try:
                self._seq = max(self._seq, int(doc.get("_id", 0)))
            except (TypeError, ValueError):
                continue

    def _quarantine(self, exc):
        """Never let an unreadable file be replaced by an empty one.

        The next flush writes whatever is in memory, so the original is
        moved aside first and the loss stays recoverable."""
        if not os.path.exists(self._file) or os.path.getsize(self._file) == 0:
            return
        backup = f"{self._file}.unreadable-{time.strftime('%Y%m%d-%H%M%S')}"
        try:
            os.replace(self._file, backup)
        except OSError:
            return
        print(
            f"[db] {os.path.basename(self._file)} could not be read ({exc}). "
            f"A copy was kept as {os.path.basename(backup)} and this "
            f"collection starts empty."
        )

    def _flush(self):
        temp = self._file + ".tmp"
        with open(temp, "w", encoding="utf-8") as handle:
            json.dump(self._docs, handle, ensure_ascii=False, default=str)
        os.replace(temp, self._file)

    def _match(self, doc, filt):
        for key, value in (filt or {}).items():
            if key == "$or":
                if not any(self._match(doc, sub) for sub in value):
                    return False
            elif isinstance(value, dict) and "$in" in value:
                if doc.get(key) not in value["$in"]:
                    return False
            elif doc.get(key) != value:
                return False
        return True

    def insert_one(self, doc):
        with self._lock:
            self._seq += 1
            record = dict(doc)
            record.setdefault("_id", self._seq)
            self._docs.append(record)
            self._flush()
            return SimpleNamespace(inserted_id=record["_id"])

    def find(self, filt=None):
        with self._lock:
            return [dict(d) for d in self._docs if self._match(d, filt or {})]

    def find_one(self, filt=None):
        with self._lock:
            for doc in self._docs:
                if self._match(doc, filt or {}):
                    return dict(doc)
        return None

    def update_one(self, filt, update, upsert=False):
        with self._lock:
            for doc in self._docs:
                if self._match(doc, filt or {}):
                    if "$set" in update:
                        doc.update(update["$set"])
                    self._flush()
                    return SimpleNamespace(modified_count=1)
            if upsert:
                record = dict(filt or {})
                record.update(update.get("$set", {}))
                self.insert_one(record)
            return SimpleNamespace(modified_count=0)

    def delete_one(self, filt):
        with self._lock:
            for index, doc in enumerate(self._docs):
                if self._match(doc, filt or {}):
                    self._docs.pop(index)
                    self._flush()
                    return SimpleNamespace(deleted_count=1)
            return SimpleNamespace(deleted_count=0)

    def count_documents(self, filt=None):
        with self._lock:
            return sum(1 for doc in self._docs if self._match(doc, filt or {}))


def init_db():
    try:
        client = MongoClient(Config.MONGO_URI, serverSelectionTimeoutMS=2000)
        client.admin.command("ping")
        _state["mongo"] = client[Config.DB_NAME]
        _state["mode"] = "mongo"
    except Exception:
        _state["mongo"] = None
        _state["mode"] = "file"
        try:
            os.makedirs(Config.DATA_DIR, exist_ok=True)
        except OSError:
            _state["mode"] = "memory"


def get_collection(name):
    if _state["mongo"] is not None:
        return _state["mongo"][name]
    if name not in _state["memory"]:
        _state["memory"][name] = MemoryCollection(name, Config.DATA_DIR)
    return _state["memory"][name]


def get_db_backend():
    return _state["mode"]